using System.Text;
using System.Threading.Channels;
using System.Windows.Forms;
using Antigooglity.WebView2Host.Protocol;

namespace Antigooglity.WebView2Host;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        try
        {
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = new UTF8Encoding(false);
        }
        catch
        {
            // Ignore when standard handles are redirected without Win32 console buffer
        }

        JsonLineProtocol.LogDiagnostic("Antigooglity WebView2 Host starting...");

        // Parse optional custom user data folder from arguments or environment
        string? customProfile = null;
        for (var i = 0; i < args.Length; i++)
        {
            if ((args[i] == "--user-data-dir" || args[i] == "-profile") && i + 1 < args.Length)
            {
                customProfile = args[i + 1];
                i++;
            }
            else if (args[i].StartsWith("--user-data-dir="))
            {
                customProfile = args[i].Substring("--user-data-dir=".Length);
            }
        }

        if (string.IsNullOrWhiteSpace(customProfile))
        {
            customProfile = Environment.GetEnvironmentVariable("ANTIGOOGLITY_WEBVIEW2_PROFILE");
        }

        ApplicationConfiguration.Initialize();

        using var form = new BrowserHostForm();
        using var controller = new BrowserController(customProfile);
        controller.AttachForm(form);

        var appCtx = new ApplicationContext();
        var isExiting = 0;

        void SafeExit()
        {
            if (Interlocked.Exchange(ref isExiting, 1) == 0)
            {
                JsonLineProtocol.LogDiagnostic("Shutting down WebView2 Host application loop...");
                try
                {
                    if (form.IsHandleCreated && !form.IsDisposed)
                    {
                        form.BeginInvoke(new Action(() =>
                        {
                            controller.Dispose();
                            appCtx.ExitThread();
                        }));
                    }
                    else
                    {
                        controller.Dispose();
                        appCtx.ExitThread();
                    }
                }
                catch
                {
                    Environment.Exit(0);
                }
            }
        }

        AppDomain.CurrentDomain.ProcessExit += (_, _) =>
        {
            controller.Dispose();
        };

        var syncContext = SynchronizationContext.Current;
        if (syncContext == null)
        {
            syncContext = new WindowsFormsSynchronizationContext();
            SynchronizationContext.SetSynchronizationContext(syncContext);
        }

        // Sequential command queue channel for thread-safe STA execution
        var commandChannel = Channel.CreateUnbounded<HostCommand>(new UnboundedChannelOptions
        {
            SingleWriter = true,
            SingleReader = true
        });

        // Post initialization and command processor onto the STA message loop
        syncContext.Post(async _ =>
        {
            try
            {
                await controller.InitializeAsync(form.Handle);
                JsonLineProtocol.LogDiagnostic("WebView2 Host ready to accept commands.");

                // Start background reader for JSON Lines protocol on stdin
                var readerThread = new Thread(() => RunStdinReader(commandChannel, SafeExit))
                {
                    IsBackground = true,
                    Name = "StdinProtocolReader"
                };
                readerThread.Start();

                // Sequential command consumer running strictly on the STA thread
                await ProcessCommandsSequentiallyAsync(commandChannel.Reader, controller, SafeExit);
            }
            catch (Exception ex)
            {
                JsonLineProtocol.LogDiagnostic($"FATAL: WebView2 initialization or processing failed: {ex}");
                JsonLineProtocol.SendResponse(HostResponse.CreateError("init", "INITIALIZATION", ex.Message));
                SafeExit();
            }
        }, null);

        // Run STA Message Loop
        Application.Run(appCtx);

        JsonLineProtocol.LogDiagnostic("Antigooglity WebView2 Host exited cleanly.");
    }

    private static void RunStdinReader(Channel<HostCommand> commandChannel, Action exitAction)
    {
        using var stdinReader = new StreamReader(Console.OpenStandardInput(), Encoding.UTF8);

        try
        {
            while (true)
            {
                var line = stdinReader.ReadLine();
                if (line == null)
                {
                    // EOF detected (parent process closed stdin or terminated)
                    JsonLineProtocol.LogDiagnostic("EOF on stdin detected. Completing command channel...");
                    commandChannel.Writer.TryComplete();
                    exitAction();
                    break;
                }

                var command = JsonLineProtocol.ParseCommand(line, out var parseError);
                if (command == null)
                {
                    if (!string.IsNullOrEmpty(parseError))
                    {
                        JsonLineProtocol.SendResponse(HostResponse.CreateError("unknown", "SYNTAX_ERROR", parseError));
                    }
                    continue;
                }

                // Enqueue command for sequential execution on the STA thread
                commandChannel.Writer.TryWrite(command);
            }
        }
        catch (Exception ex)
        {
            JsonLineProtocol.LogDiagnostic($"Reader exception: {ex.Message}");
            commandChannel.Writer.TryComplete(ex);
            exitAction();
        }
    }

    private static async Task ProcessCommandsSequentiallyAsync(
        ChannelReader<HostCommand> reader,
        BrowserController controller,
        Action exitAction)
    {
        try
        {
            while (await reader.WaitToReadAsync())
            {
                while (reader.TryRead(out var cmd))
                {
                    try
                    {
                        await ProcessCommandOnStaThreadAsync(cmd, controller, exitAction);
                    }
                    catch (Exception ex)
                    {
                        JsonLineProtocol.LogDiagnostic($"Unhandled exception processing '{cmd.Command}': {ex}");
                        JsonLineProtocol.SendResponse(HostResponse.CreateError(cmd.RequestId, cmd.Command, ex.Message));
                    }
                }
            }
        }
        catch (Exception ex)
        {
            JsonLineProtocol.LogDiagnostic($"Command sequential loop terminated: {ex.Message}");
        }
    }

    private static async Task ProcessCommandOnStaThreadAsync(
        HostCommand cmd,
        BrowserController controller,
        Action exitAction)
    {
        switch (cmd.Command.ToUpperInvariant())
        {
            case "PING":
            {
                var response = controller.HandlePing(cmd);
                JsonLineProtocol.SendResponse(response);
                break;
            }

            case "GET_STATUS":
            {
                var response = controller.HandleGetStatus(cmd);
                JsonLineProtocol.SendResponse(response);
                break;
            }

            case "GET_CURRENT_URL":
            {
                var response = controller.HandleGetCurrentUrl(cmd);
                JsonLineProtocol.SendResponse(response);
                break;
            }

            case "GET_NAVIGATION_STATUS":
            {
                var response = controller.HandleGetNavigationStatus(cmd);
                JsonLineProtocol.SendResponse(response);
                break;
            }

            case "SET_VISIBILITY":
            {
                var response = controller.HandleSetVisibility(cmd);
                JsonLineProtocol.SendResponse(response);
                break;
            }

            case "GET_DOCUMENT_INFO":
            {
                var response = await controller.HandleGetDocumentInfoAsync(cmd);
                JsonLineProtocol.SendResponse(response);
                break;
            }

            case "GET_PAGE_TEXT":
            {
                var response = await controller.HandleGetPageTextAsync(cmd);
                JsonLineProtocol.SendResponse(response);
                break;
            }

            case "NAVIGATE":
            {
                var response = await controller.HandleNavigateAsync(cmd);
                JsonLineProtocol.SendResponse(response);
                break;
            }

            case "EXECUTE_SCRIPT":
            {
                var response = await controller.HandleExecuteScriptAsync(cmd);
                JsonLineProtocol.SendResponse(response);
                break;
            }

            case "CLOSE":
            {
                var response = controller.HandleClose(cmd);
                JsonLineProtocol.SendResponse(response);
                exitAction();
                break;
            }

            default:
            {
                JsonLineProtocol.SendResponse(HostResponse.CreateError(
                    cmd.RequestId,
                    cmd.Command,
                    $"Unknown command: '{cmd.Command}'"
                ));
                break;
            }
        }
    }
}
