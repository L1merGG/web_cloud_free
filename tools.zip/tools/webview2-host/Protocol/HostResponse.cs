using System.Text.Json.Serialization;

namespace Antigooglity.WebView2Host.Protocol;

public class HostResponse
{
    [JsonPropertyName("requestId")]
    public string RequestId { get; set; } = string.Empty;

    [JsonPropertyName("command")]
    public string Command { get; set; } = string.Empty;

    [JsonPropertyName("success")]
    public bool Success { get; set; }

    [JsonPropertyName("data")]
    public object? Data { get; set; }

    [JsonPropertyName("error")]
    public string? Error { get; set; }

    public static HostResponse CreateSuccess(string requestId, string command, object? data = null)
    {
        return new HostResponse
        {
            RequestId = requestId,
            Command = command,
            Success = true,
            Data = data,
            Error = null
        };
    }

    public static HostResponse CreateError(string requestId, string command, string error)
    {
        return new HostResponse
        {
            RequestId = requestId,
            Command = command,
            Success = false,
            Data = null,
            Error = error
        };
    }
}
