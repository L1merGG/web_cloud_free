using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace Antigooglity.WebView2Host.Protocol;

public static class JsonLineProtocol
{
    public const int MaxLineLength = 10 * 1024 * 1024; // 10 MB limit

    private static readonly object WriteLock = new();
    private static readonly object ErrorLock = new();

    private static readonly StreamWriter StdoutWriter = new(Console.OpenStandardOutput(), new UTF8Encoding(false))
    {
        AutoFlush = true
    };

    private static readonly StreamWriter StderrWriter = new(Console.OpenStandardError(), new UTF8Encoding(false))
    {
        AutoFlush = true
    };

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        WriteIndented = false
    };

    public static HostCommand? ParseCommand(string? line, out string? parseError)
    {
        parseError = null;
        if (line == null)
        {
            return null;
        }

        if (line.Length > MaxLineLength)
        {
            parseError = $"Message size exceeds maximum limit of {MaxLineLength} bytes";
            return null;
        }

        var trimmed = line.Trim();
        if (string.IsNullOrEmpty(trimmed))
        {
            return null;
        }

        try
        {
            var command = JsonSerializer.Deserialize<HostCommand>(trimmed, JsonOptions);
            if (command == null || string.IsNullOrWhiteSpace(command.RequestId) || string.IsNullOrWhiteSpace(command.Command))
            {
                parseError = "Invalid command format: 'requestId' and 'command' are required";
                return null;
            }
            return command;
        }
        catch (JsonException ex)
        {
            parseError = $"JSON syntax error: {ex.Message}";
            return null;
        }
    }

    public static void SendResponse(HostResponse response)
    {
        var json = JsonSerializer.Serialize(response, JsonOptions);
        lock (WriteLock)
        {
            StdoutWriter.WriteLine(json);
        }
    }

    public static void LogDiagnostic(string message)
    {
        try
        {
            lock (ErrorLock)
            {
                StderrWriter.WriteLine($"[WebView2Host {DateTime.UtcNow:HH:mm:ss.fff}] {message}");
            }
        }
        catch
        {
            // Ignore stderr logging failure
        }
    }
}
