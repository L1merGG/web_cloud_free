using System.Drawing;
using System.Windows.Forms;

namespace Antigooglity.WebView2Host;

public class BrowserHostForm : Form
{
    private bool _allowVisible;

    public bool IsDiagnosticVisible => _allowVisible;

    public event Action<bool>? VisibilityChanged;

    public BrowserHostForm()
    {
        Text = "Antigooglity - WebView2 Diagnostic Window";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1280, 800);
        MinimumSize = new Size(600, 400);
        FormBorderStyle = FormBorderStyle.Sizable;
        ShowInTaskbar = true;
        WindowState = FormWindowState.Normal;
        Opacity = 1.0;

        // Force native HWND handle creation so WebView2 can attach
        CreateHandle();
    }

    public void SetDiagnosticVisibility(bool visible)
    {
        _allowVisible = visible;
        if (visible)
        {
            Show();
            BringToFront();
            Activate();
        }
        else
        {
            Hide();
        }

        VisibilityChanged?.Invoke(visible);
    }

    protected override void SetVisibleCore(bool value)
    {
        base.SetVisibleCore(_allowVisible && value);
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (e.CloseReason == CloseReason.UserClosing)
        {
            // If user closes diagnostic window, switch back to hidden mode instead of killing the process
            e.Cancel = true;
            SetDiagnosticVisibility(false);
        }
        else
        {
            base.OnFormClosing(e);
        }
    }
}
