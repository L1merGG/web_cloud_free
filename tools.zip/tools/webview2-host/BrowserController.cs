using System.Drawing;
using System.Text.Json;
using Antigooglity.WebView2Host.Protocol;
using Microsoft.Web.WebView2.Core;

namespace Antigooglity.WebView2Host;

public class BrowserController : IDisposable
{
    private CoreWebView2Environment? _environment;
    private CoreWebView2Controller? _controller;
    private CoreWebView2? _coreWebView2;
    private BrowserHostForm? _form;
    private bool _isNavigating;

    public bool IsInitialized => _coreWebView2 != null;
    public string? RuntimeVersion { get; private set; }
    public string UserDataFolder { get; }

    public BrowserController(string? customUserDataFolder = null)
    {
        if (!string.IsNullOrWhiteSpace(customUserDataFolder))
        {
            UserDataFolder = Path.GetFullPath(customUserDataFolder);
        }
        else
        {
            var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            UserDataFolder = Path.Combine(localAppData, "Antigooglity", "webview2-profile");
        }
        Directory.CreateDirectory(UserDataFolder);
    }

    public void AttachForm(BrowserHostForm form)
    {
        _form = form;
        _form.Resize += (_, _) =>
        {
            if (_controller != null && _controller.IsVisible && _form.ClientRectangle.Width > 0 && _form.ClientRectangle.Height > 0)
            {
                _controller.Bounds = _form.ClientRectangle;
            }
        };

        _form.VisibilityChanged += visible =>
        {
            if (_controller != null)
            {
                _controller.IsVisible = visible;
                if (visible && _form.ClientRectangle.Width > 0 && _form.ClientRectangle.Height > 0)
                {
                    _controller.Bounds = _form.ClientRectangle;
                }
                else
                {
                    _controller.Bounds = new Rectangle(0, 0, 1280, 800);
                }
            }
        };
    }

    public async Task InitializeAsync(IntPtr hwnd)
    {
        try
        {
            RuntimeVersion = CoreWebView2Environment.GetAvailableBrowserVersionString();
            JsonLineProtocol.LogDiagnostic($"WebView2 Runtime detected: {RuntimeVersion}");
        }
        catch (Exception ex)
        {
            JsonLineProtocol.LogDiagnostic($"Failed to detect WebView2 Runtime via GetAvailableBrowserVersionString: {ex.Message}");
            throw;
        }

        JsonLineProtocol.LogDiagnostic($"Initializing CoreWebView2Environment with profile: {UserDataFolder}");
        _environment = await CoreWebView2Environment.CreateAsync(browserExecutableFolder: null, userDataFolder: UserDataFolder);

        JsonLineProtocol.LogDiagnostic($"Creating CoreWebView2Controller on HWND 0x{hwnd:X}...");
        _controller = await _environment.CreateCoreWebView2ControllerAsync(hwnd);

        // Explicit requirement: Hidden mode by default
        _controller.Bounds = new Rectangle(0, 0, 1280, 800);
        _controller.IsVisible = false;
        _controller.DefaultBackgroundColor = Color.Transparent;

        _coreWebView2 = _controller.CoreWebView2;

        _coreWebView2.NavigationStarting += (_, _) => _isNavigating = true;
        _coreWebView2.NavigationCompleted += (_, _) => _isNavigating = false;

        // Security and stability settings
        _coreWebView2.Settings.IsStatusBarEnabled = false;
        _coreWebView2.Settings.AreDevToolsEnabled = false;
        _coreWebView2.Settings.IsBuiltInErrorPageEnabled = true;
        _coreWebView2.Settings.AreDefaultScriptDialogsEnabled = true;

        JsonLineProtocol.LogDiagnostic($"WebView2 initialized successfully. IsVisible: {_controller.IsVisible}");
    }

    public HostResponse HandlePing(HostCommand cmd)
    {
        return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new
        {
            message = "PONG",
            timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            runtimeVersion = RuntimeVersion
        });
    }

    public HostResponse HandleGetStatus(HostCommand cmd)
    {
        return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new
        {
            initialized = IsInitialized,
            runtimeVersion = RuntimeVersion,
            userDataFolder = UserDataFolder,
            isVisible = _controller?.IsVisible ?? false,
            formVisible = _form?.IsDiagnosticVisible ?? false,
            currentUrl = _coreWebView2?.Source ?? string.Empty
        });
    }

    public HostResponse HandleGetCurrentUrl(HostCommand cmd)
    {
        if (!IsInitialized || _coreWebView2 == null)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "WebView2 is not initialized");
        }

        return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new
        {
            url = _coreWebView2.Source
        });
    }

    public HostResponse HandleGetNavigationStatus(HostCommand cmd)
    {
        if (!IsInitialized || _coreWebView2 == null)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "WebView2 is not initialized");
        }

        return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new
        {
            currentUrl = _coreWebView2.Source,
            isNavigating = _isNavigating,
            canGoBack = _coreWebView2.CanGoBack,
            canGoForward = _coreWebView2.CanGoForward,
            documentTitle = _coreWebView2.DocumentTitle
        });
    }

    public HostResponse HandleSetVisibility(HostCommand cmd)
    {
        if (!IsInitialized || _controller == null)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "WebView2 is not initialized");
        }

        if (!cmd.Visible.HasValue)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "The 'visible' parameter (boolean) is required for SET_VISIBILITY");
        }

        var visible = cmd.Visible.Value;
        JsonLineProtocol.LogDiagnostic($"SET_VISIBILITY requested: {visible}");

        if (_form != null)
        {
            _form.SetDiagnosticVisibility(visible);
        }

        _controller.IsVisible = visible;
        if (visible && _form != null && _form.ClientRectangle.Width > 0 && _form.ClientRectangle.Height > 0)
        {
            _controller.Bounds = _form.ClientRectangle;
        }
        else
        {
            _controller.Bounds = new Rectangle(0, 0, 1280, 800);
        }

        return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new
        {
            isVisible = _controller.IsVisible,
            formVisible = _form?.IsDiagnosticVisible ?? false
        });
    }

    public async Task<HostResponse> HandleNavigateAsync(HostCommand cmd)
    {
        if (!IsInitialized || _coreWebView2 == null)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "WebView2 is not initialized");
        }

        if (string.IsNullOrWhiteSpace(cmd.Url))
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "URL parameter is required for NAVIGATE");
        }

        var tcs = new TaskCompletionSource<NavigationResult>(TaskCreationOptions.RunContinuationsAsynchronously);
        var timeoutMs = cmd.TimeoutMs ?? 30000;

        void NavigationCompletedHandler(object? sender, CoreWebView2NavigationCompletedEventArgs e)
        {
            tcs.TrySetResult(new NavigationResult(e.IsSuccess, e.WebErrorStatus.ToString(), e.HttpStatusCode));
        }

        _coreWebView2.NavigationCompleted += NavigationCompletedHandler;

        try
        {
            JsonLineProtocol.LogDiagnostic($"Navigating to '{cmd.Url}' (timeout: {timeoutMs}ms)...");
            _coreWebView2.Navigate(cmd.Url);

            using var cts = new CancellationTokenSource(timeoutMs);
            using (cts.Token.Register(() => tcs.TrySetCanceled()))
            {
                var result = await tcs.Task;
                JsonLineProtocol.LogDiagnostic($"Navigation completed. Success: {result.IsSuccess}, Status: {result.ErrorStatus}, HTTP: {result.HttpStatusCode}");

                return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new
                {
                    url = _coreWebView2.Source,
                    isSuccess = result.IsSuccess,
                    errorStatus = result.ErrorStatus,
                    httpStatusCode = result.HttpStatusCode
                });
            }
        }
        catch (TaskCanceledException)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, $"Navigation timed out after {timeoutMs}ms");
        }
        catch (Exception ex)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, $"Navigation failed: {ex.Message}");
        }
        finally
        {
            _coreWebView2.NavigationCompleted -= NavigationCompletedHandler;
        }
    }

    public async Task<HostResponse> HandleExecuteScriptAsync(HostCommand cmd)
    {
        if (!IsInitialized || _coreWebView2 == null)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "WebView2 is not initialized");
        }

        if (string.IsNullOrWhiteSpace(cmd.Script))
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "Script parameter is required for EXECUTE_SCRIPT");
        }

        var timeoutMs = cmd.TimeoutMs ?? 15000;

        try
        {
            using var cts = new CancellationTokenSource(timeoutMs);
            var executeTask = _coreWebView2.ExecuteScriptAsync(cmd.Script);

            var completedTask = await Task.WhenAny(executeTask, Task.Delay(timeoutMs, cts.Token));
            if (completedTask != executeTask)
            {
                return HostResponse.CreateError(cmd.RequestId, cmd.Command, $"Script execution timed out after {timeoutMs}ms");
            }

            cts.Cancel();
            var rawJsonResult = await executeTask;

            object? parsedResult = null;
            if (!string.IsNullOrEmpty(rawJsonResult) && rawJsonResult != "null")
            {
                try
                {
                    using var doc = JsonDocument.Parse(rawJsonResult);
                    parsedResult = doc.RootElement.Clone();
                }
                catch
                {
                    parsedResult = rawJsonResult;
                }
            }

            // Return single result property without duplicating rawJsonResult
            return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new
            {
                result = parsedResult
            });
        }
        catch (Exception ex)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, $"Script execution error: {ex.Message}");
        }
    }

    public async Task<HostResponse> HandleGetDocumentInfoAsync(HostCommand cmd)
    {
        if (!IsInitialized || _coreWebView2 == null)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "WebView2 is not initialized");
        }

        const string script = """
            JSON.stringify({
                href: window.location.href,
                title: document.title,
                readyState: document.readyState,
                visibilityState: document.visibilityState,
                hasFocus: document.hasFocus()
            })
            """;

        var timeoutMs = cmd.TimeoutMs ?? 10000;
        try
        {
            using var cts = new CancellationTokenSource(timeoutMs);
            var executeTask = _coreWebView2.ExecuteScriptAsync(script);

            var completedTask = await Task.WhenAny(executeTask, Task.Delay(timeoutMs, cts.Token));
            if (completedTask != executeTask)
            {
                return HostResponse.CreateError(cmd.RequestId, cmd.Command, $"GET_DOCUMENT_INFO timed out after {timeoutMs}ms");
            }

            cts.Cancel();
            var rawJsonResult = await executeTask;

            if (string.IsNullOrEmpty(rawJsonResult) || rawJsonResult == "null")
            {
                return HostResponse.CreateError(cmd.RequestId, cmd.Command, "GET_DOCUMENT_INFO returned null");
            }

            string innerJson;
            try
            {
                using var doc = JsonDocument.Parse(rawJsonResult);
                innerJson = doc.RootElement.ValueKind == JsonValueKind.String
                    ? doc.RootElement.GetString() ?? "{}"
                    : rawJsonResult;
            }
            catch
            {
                innerJson = rawJsonResult;
            }

            using var innerDoc = JsonDocument.Parse(innerJson);
            var root = innerDoc.RootElement;

            return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new
            {
                href = root.TryGetProperty("href", out var p) ? p.GetString() : string.Empty,
                title = root.TryGetProperty("title", out p) ? p.GetString() : string.Empty,
                readyState = root.TryGetProperty("readyState", out p) ? p.GetString() : string.Empty,
                visibilityState = root.TryGetProperty("visibilityState", out p) ? p.GetString() : string.Empty,
                hasFocus = root.TryGetProperty("hasFocus", out p) && p.GetBoolean()
            });
        }
        catch (Exception ex)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, $"GET_DOCUMENT_INFO error: {ex.Message}");
        }
    }

    public async Task<HostResponse> HandleGetPageTextAsync(HostCommand cmd)
    {
        if (!IsInitialized || _coreWebView2 == null)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, "WebView2 is not initialized");
        }

        const string script = "(function() { return (document.body && document.body.innerText) ? document.body.innerText : ''; })()";
        var timeoutMs = cmd.TimeoutMs ?? 10000;
        var maxLength = cmd.MaxLength ?? 4000;

        try
        {
            using var cts = new CancellationTokenSource(timeoutMs);
            var executeTask = _coreWebView2.ExecuteScriptAsync(script);

            var completedTask = await Task.WhenAny(executeTask, Task.Delay(timeoutMs, cts.Token));
            if (completedTask != executeTask)
            {
                return HostResponse.CreateError(cmd.RequestId, cmd.Command, $"GET_PAGE_TEXT timed out after {timeoutMs}ms");
            }

            cts.Cancel();
            var rawJsonResult = await executeTask;

            string fullText = string.Empty;
            if (!string.IsNullOrEmpty(rawJsonResult) && rawJsonResult != "null")
            {
                try
                {
                    using var doc = JsonDocument.Parse(rawJsonResult);
                    fullText = doc.RootElement.ValueKind == JsonValueKind.String
                        ? doc.RootElement.GetString() ?? string.Empty
                        : rawJsonResult;
                }
                catch
                {
                    fullText = rawJsonResult;
                }
            }

            var originalLength = fullText.Length;
            var truncated = false;
            var text = fullText;

            if (text.Length > maxLength)
            {
                text = text.Substring(0, maxLength);
                truncated = true;
            }

            return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new
            {
                text = text,
                length = originalLength,
                truncated = truncated
            });
        }
        catch (Exception ex)
        {
            return HostResponse.CreateError(cmd.RequestId, cmd.Command, $"GET_PAGE_TEXT error: {ex.Message}");
        }
    }

    public HostResponse HandleClose(HostCommand cmd)
    {
        JsonLineProtocol.LogDiagnostic("CLOSE command received. Closing WebView2...");
        Dispose();
        return HostResponse.CreateSuccess(cmd.RequestId, cmd.Command, new { closed = true });
    }

    public void Dispose()
    {
        try
        {
            if (_controller != null)
            {
                _controller.IsVisible = false;
                _controller.Close();
                _controller = null;
            }
            _coreWebView2 = null;
            _environment = null;
        }
        catch (Exception ex)
        {
            JsonLineProtocol.LogDiagnostic($"Error disposing WebView2: {ex.Message}");
        }
    }

    private record NavigationResult(bool IsSuccess, string ErrorStatus, int HttpStatusCode);
}
