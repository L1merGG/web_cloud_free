$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

$s = @"
(function() {
    try {
        var editor = document.querySelector('.ql-editor');
        if (!editor) return { error: 'No editor' };
        editor.focus();
        var ok = document.execCommand('insertText', false, 'Тест ввода');
        var text = editor.innerText ? editor.innerText.trim() : '';

        // Check for send button
        var sendBtn = document.querySelector('button[aria-label*="Отправить"]') ||
                      document.querySelector('button[aria-label*="Send"]') ||
                      document.querySelector('.send-button') ||
                      document.querySelector('button.send-button-container');

        var aria = sendBtn ? sendBtn.getAttribute('aria-label') : null;
        var dis = sendBtn ? sendBtn.disabled : null;

        return {
            execResult: ok,
            editorText: text,
            hasSendBtn: !!sendBtn,
            sendAria: aria,
            sendDisabled: dis
        };
    } catch(err) {
        return { error: err.toString() };
    }
})()
"@

$cmd = @{ requestId = "3"; command = "EXECUTE_SCRIPT"; script = "($s)" } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$r = $proc.StandardOutput.ReadLine()
Write-Host "RESULT: $r"

$proc.StandardInput.WriteLine('{"requestId":"4","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
