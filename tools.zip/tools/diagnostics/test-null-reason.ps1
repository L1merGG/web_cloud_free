$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

# Test a: document.querySelector('.ql-editor') == null
$scriptA = "document.querySelector('.ql-editor') !== null"
$cmdA = @{ requestId = "3"; command = "EXECUTE_SCRIPT"; script = $scriptA } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmdA)
$proc.StandardInput.Flush()
$resA = $proc.StandardOutput.ReadLine()
Write-Host "resA: $resA"

# Test b: typeof document.querySelector('.ql-editor').innerHTML
$scriptB = "typeof (document.querySelector('.ql-editor') ? document.querySelector('.ql-editor').innerHTML : 'none')"
$cmdB = @{ requestId = "4"; command = "EXECUTE_SCRIPT"; script = $scriptB } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmdB)
$proc.StandardInput.Flush()
$resB = $proc.StandardOutput.ReadLine()
Write-Host "resB: $resB"

$proc.StandardInput.WriteLine('{"requestId":"5","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
