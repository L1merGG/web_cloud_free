Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('cmd.exe', 'powershell.exe', 'pwsh.exe') } | Select-Object ProcessId, Name, CommandLine
