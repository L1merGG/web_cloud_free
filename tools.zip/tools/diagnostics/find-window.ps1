$p = Get-Process -Name AntigooglityWebView2Host -ErrorAction SilentlyContinue
if ($p) {
    Write-Host "PID: $($p.Id), SessionId: $($p.SessionId), MainWindowHandle: $($p.MainWindowHandle), MainWindowTitle: '$($p.MainWindowTitle)'"
} else {
    Write-Host "Process not running"
}

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WinSearch {
    [DllImport("user32.dll")] public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
}
"@ -ErrorAction SilentlyContinue

$h = [WinSearch]::FindWindow($null, "Antigooglity - WebView2 Diagnostic Window")
Write-Host "FindWindow result: $h"
if ($h -ne [IntPtr]::Zero) {
    $r = New-Object WinSearch+RECT
    [WinSearch]::GetWindowRect($h, [ref]$r)
    $vis = [WinSearch]::IsWindowVisible($h)
    Write-Host "Rect: Left=$($r.Left), Top=$($r.Top), Right=$($r.Right), Bottom=$($r.Bottom), Visible=$vis"
}

Get-Process | Where-Object { $_.MainWindowTitle -like "*Antigooglity*" } | Select-Object Id, ProcessName, MainWindowTitle, MainWindowHandle
