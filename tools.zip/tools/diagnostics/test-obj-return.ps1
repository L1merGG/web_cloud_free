$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

$s1 = "JSON.stringify({ a: 1, b: 'hello' })"
$c1 = @{ requestId = "3"; command = "EXECUTE_SCRIPT"; script = $s1 } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($c1)
$proc.StandardInput.Flush()
$r1 = $proc.StandardOutput.ReadLine()
Write-Host "r1: $r1"

$s2 = "({ a: 1, b: 'hello' })"
$c2 = @{ requestId = "4"; command = "EXECUTE_SCRIPT"; script = $s2 } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($c2)
$proc.StandardInput.Flush()
$r2 = $proc.StandardOutput.ReadLine()
Write-Host "r2: $r2"

$proc.StandardInput.WriteLine('{"requestId":"5","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
