$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 6

$probeContainers = @'
JSON.stringify({
    allElements: Array.from(document.querySelectorAll('*')).map(el => {
        var tn = el.tagName.toLowerCase();
        if (tn.includes('message') || tn.includes('response') || tn.includes('query') || tn.includes('turn') || tn.includes('chat') || tn.includes('model')) {
            return {
                tag: el.tagName,
                className: el.className,
                testId: el.getAttribute('data-test-id'),
                text: (el.innerText || '').trim().substring(0, 80)
            };
        }
        return null;
    }).filter(Boolean).slice(0, 25)
})
'@

$cmd = @{ requestId = "3"; command = "EXECUTE_SCRIPT"; script = $probeContainers } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$res = $proc.StandardOutput.ReadLine()
Write-Host "CONTAINERS: $res"

$proc.StandardInput.WriteLine('{"requestId":"4","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
