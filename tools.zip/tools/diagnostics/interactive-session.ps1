[CmdletBinding()]
param(
    [string]$ActionFile = "tools/diagnostics/action.txt",
    [string]$StatusFile = "tools/diagnostics/status.json"
)

$ErrorActionPreference = "Stop"

try {
    if (-not $env:DOTNET_ROOT) {
        $dotnetDefault = "$env:LOCALAPPDATA\Microsoft\dotnet"
        if (Test-Path $dotnetDefault) {
            $env:DOTNET_ROOT = $dotnetDefault
            $env:PATH = "$dotnetDefault;$env:PATH"
        }
    }

    $hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"
    $profileDir = "$env:LOCALAPPDATA\Antigooglity\webview2-profile"

    function Start-WebView2Host {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $hostExe
        $psi.UseShellExecute = $false
        $psi.RedirectStandardInput = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
        $psi.StandardErrorEncoding = [System.Text.Encoding]::UTF8
        $psi.CreateNoWindow = $true

        if ($env:DOTNET_ROOT) {
            $psi.EnvironmentVariables["DOTNET_ROOT"] = $env:DOTNET_ROOT
        }

        $proc = [System.Diagnostics.Process]::Start($psi)

        $errJob = [powershell]::Create().AddScript({
            param($process)
            while (-not $process.HasExited) {
                $line = $process.StandardError.ReadLine()
                if ($line) {
                    [Console]::ForegroundColor = [ConsoleColor]::DarkGray
                    [Console]::Error.WriteLine("  $line")
                    [Console]::ResetColor()
                }
            }
        }).AddArgument($proc)
        $null = $errJob.BeginInvoke()

        return $proc
    }

    $script:reqCounter = 0

    function Invoke-HostCommand {
        param(
            [Parameter(Mandatory=$true)] $Process,
            [Parameter(Mandatory=$true)] [string] $Command,
            [hashtable] $ExtraArgs = @{},
            [int] $TimeoutSec = 30
        )

        $script:reqCounter++
        $reqId = "req-$($script:reqCounter)"

        $payload = @{
            requestId = $reqId
            command = $Command
        }
        foreach ($k in $ExtraArgs.Keys) {
            $payload[$k] = $ExtraArgs[$k]
        }

        $json = $payload | ConvertTo-Json -Compress
        $Process.StandardInput.WriteLine($json)
        $Process.StandardInput.Flush()

        $line = $Process.StandardOutput.ReadLine()
        if ($null -eq $line) {
            throw "Host process stdout reached EOF while waiting for command '$Command'"
        }

        return ($line | ConvertFrom-Json)
    }

    function Write-SessionStatus {
        param([hashtable]$StatusData)
        $StatusData["updatedAt"] = (Get-Date).ToString("o")
        $json = $StatusData | ConvertTo-Json -Depth 5
        Set-Content -Path $StatusFile -Value $json -Encoding UTF8
    }

    Write-Host "Starting Interactive WebView2 Session Controller..." -ForegroundColor Cyan

    if (Test-Path $ActionFile) { Remove-Item $ActionFile -Force }
    if (Test-Path $StatusFile) { Remove-Item $StatusFile -Force }

    $proc = Start-WebView2Host
    Start-Sleep -Milliseconds 800

    $ping = Invoke-HostCommand -Process $proc -Command "PING"
    Write-Host "Host started. Runtime: $($ping.data.runtimeVersion)" -ForegroundColor Green

    # Make window visible
    $null = Invoke-HostCommand -Process $proc -Command "SET_VISIBILITY" -ExtraArgs @{ visible = $true }
    Write-Host "Diagnostic window is visible on desktop." -ForegroundColor Green

    # Navigate to Google Sign-In
    Write-Host "Navigating to https://accounts.google.com/..." -ForegroundColor Yellow
    $nav = Invoke-HostCommand -Process $proc -Command "NAVIGATE" -ExtraArgs @{ url = "https://accounts.google.com/"; timeoutMs = 45000 }
    Write-Host "Navigation completed: $($nav.data.url)" -ForegroundColor Green

    Start-Sleep -Seconds 2

    $doc = Invoke-HostCommand -Process $proc -Command "GET_DOCUMENT_INFO"
    $txt = Invoke-HostCommand -Process $proc -Command "GET_PAGE_TEXT" -ExtraArgs @{ maxLength = 1000 }

    Write-SessionStatus @{
        phase = "WAITING_FOR_USER_LOGIN"
        url = $doc.data.href
        title = $doc.data.title
        readyState = $doc.data.readyState
        textPreview = $txt.data.text
        status = "READY_FOR_INTERACTION"
    }

    Write-Host "`n============================================================" -ForegroundColor Cyan
    Write-Host " Diagnostic window 'Antigooglity - WebView2 Diagnostic Window'" -ForegroundColor Green
    Write-Host " is now open on your desktop." -ForegroundColor Green
    Write-Host " You can perform Google login in the window." -ForegroundColor Yellow
    Write-Host "============================================================" -ForegroundColor Cyan

    $running = $true

    while ($running -and -not $proc.HasExited) {
        Start-Sleep -Milliseconds 1000

        if (Test-Path $ActionFile) {
            $actionRaw = (Get-Content $ActionFile -Raw -Encoding UTF8).Trim()
            Remove-Item $ActionFile -Force
            Write-Host "`n[ACTION RECEIVED]: $actionRaw" -ForegroundColor Yellow

            switch ($actionRaw) {
                "CHECK_LOGIN" {
                    $docInfo = Invoke-HostCommand -Process $proc -Command "GET_DOCUMENT_INFO"
                    $pageText = Invoke-HostCommand -Process $proc -Command "GET_PAGE_TEXT" -ExtraArgs @{ maxLength = 2000 }
                    $text = $pageText.data.text

                    $isBlocked = ($text -match "secure" -or
                                  $text -match "Couldn't sign you in" -or
                                  $text -match "Не удалось")
                    $isLoggedIn = ($docInfo.data.href -match "myaccount\.google\.com" -or
                                   $docInfo.data.href -match "accounts\.google\.com/b/" -or
                                   $text -match "Google Account" -or
                                   $text -match "Welcome")

                    Write-SessionStatus @{
                        phase = "LOGIN_CHECKED"
                        url = $docInfo.data.href
                        title = $docInfo.data.title
                        isBlocked = $isBlocked
                        isLoggedIn = $isLoggedIn
                        textPreview = $text
                    }

                    Write-Host "Check Login Result: isBlocked=$isBlocked, isLoggedIn=$isLoggedIn, URL=$($docInfo.data.href)" -ForegroundColor Green
                }

                "TEST_PERSISTENCE" {
                    Write-Host "Closing host to verify profile persistence..." -ForegroundColor Yellow
                    $null = Invoke-HostCommand -Process $proc -Command "CLOSE"
                    Start-Sleep -Seconds 1
                    if (-not $proc.HasExited) { $proc.Kill() }

                    Write-Host "Restarting Host with the same profile: $profileDir..." -ForegroundColor Yellow
                    $proc = Start-WebView2Host
                    Start-Sleep -Milliseconds 800
                    $null = Invoke-HostCommand -Process $proc -Command "PING"
                    $null = Invoke-HostCommand -Process $proc -Command "SET_VISIBILITY" -ExtraArgs @{ visible = $true }

                    Write-Host "Navigating to https://myaccount.google.com/..." -ForegroundColor Yellow
                    $nav2 = Invoke-HostCommand -Process $proc -Command "NAVIGATE" -ExtraArgs @{ url = "https://myaccount.google.com/"; timeoutMs = 30000 }
                    Start-Sleep -Seconds 2

                    $doc2 = Invoke-HostCommand -Process $proc -Command "GET_DOCUMENT_INFO"
                    $txt2 = Invoke-HostCommand -Process $proc -Command "GET_PAGE_TEXT" -ExtraArgs @{ maxLength = 2000 }

                    $stillLoggedIn = ($doc2.data.href -match "myaccount\.google\.com" -and
                                      $txt2.data.text -notmatch "identifier" -and
                                      $txt2.data.text -notmatch "signin")

                    Write-SessionStatus @{
                        phase = "PERSISTENCE_CHECKED"
                        url = $doc2.data.href
                        title = $doc2.data.title
                        stillLoggedIn = $stillLoggedIn
                        textPreview = $txt2.data.text
                    }

                    Write-Host "Persistence Result: stillLoggedIn=$stillLoggedIn, URL=$($doc2.data.href)" -ForegroundColor Green
                }

                "NAVIGATE_GEMINI" {
                    Write-Host "Navigating to https://gemini.google.com/..." -ForegroundColor Yellow
                    $navGemini = Invoke-HostCommand -Process $proc -Command "NAVIGATE" -ExtraArgs @{ url = "https://gemini.google.com/"; timeoutMs = 30000 }
                    Start-Sleep -Seconds 4

                    $geminiDoc = Invoke-HostCommand -Process $proc -Command "GET_DOCUMENT_INFO"
                    $geminiTxt = Invoke-HostCommand -Process $proc -Command "GET_PAGE_TEXT" -ExtraArgs @{ maxLength = 3000 }

                    $inspectScript = @'
(function() {
    var r = document.querySelector('rich-textarea') || document.querySelector('.ql-editor') || document.querySelector('textarea') || document.querySelector('[contenteditable="true"]');
    var s = document.querySelector('button[aria-label*="Send"]') || document.querySelector('button[aria-label*="Отправить"]') || document.querySelector('.send-button');
    return {
        hasInput: !!r,
        inputTag: r ? r.tagName : null,
        hasSendButton: !!s,
        sendButtonDisabled: s ? s.disabled : null,
        title: document.title,
        url: window.location.href
    };
})()
'@
                    $domInspect = Invoke-HostCommand -Process $proc -Command "EXECUTE_SCRIPT" -ExtraArgs @{ script = $inspectScript }

                    Write-SessionStatus @{
                        phase = "GEMINI_LOADED"
                        url = $geminiDoc.data.href
                        title = $geminiDoc.data.title
                        domInfo = $domInspect.data.result
                        textPreview = $geminiTxt.data.text
                    }

                    Write-Host "Gemini DOM check: $($domInspect.data.rawResult)" -ForegroundColor Green
                }

                "SEND_GEMINI_MESSAGE" {
                    Write-Host "Attempting to send test message..." -ForegroundColor Yellow

                    $sendScript = @'
(function() {
    var editor = document.querySelector('.ql-editor') || document.querySelector('[contenteditable="true"]') || document.querySelector('textarea');
    if (!editor) return { success: false, error: 'Editor not found' };
    editor.focus();
    if (editor.tagName === 'TEXTAREA') {
        editor.value = 'Ответь одним словом: READY';
    } else {
        editor.innerText = 'Ответь одним словом: READY';
    }
    editor.dispatchEvent(new Event('input', { bubbles: true }));
    var sendBtn = document.querySelector('button[aria-label*="Send"]') || document.querySelector('button[aria-label*="Отправить"]') || document.querySelector('.send-button');
    if (!sendBtn) return { success: false, error: 'Send button not found', editorText: editor.innerText };
    sendBtn.click();
    return { success: true, clicked: true };
})()
'@
                    $sendResp = Invoke-HostCommand -Process $proc -Command "EXECUTE_SCRIPT" -ExtraArgs @{ script = $sendScript }
                    Write-Host "Message send attempt: $($sendResp.data.rawResult)" -ForegroundColor Green

                    Write-Host "Waiting for Gemini response..." -ForegroundColor Yellow
                    $startWait = [DateTime]::UtcNow
                    $answerText = ""
                    $hasAnswer = $false

                    while ([DateTime]::UtcNow.Subtract($startWait).TotalSeconds -lt 30) {
                        Start-Sleep -Seconds 2
                        $readScript = @'
(function() {
    var responses = document.querySelectorAll('message-content') || document.querySelectorAll('.model-response-text');
    if (responses.length > 0) {
        var last = responses[responses.length - 1];
        return { count: responses.length, text: last.innerText };
    }
    return { count: 0, text: '' };
})()
'@
                        $respCheck = Invoke-HostCommand -Process $proc -Command "EXECUTE_SCRIPT" -ExtraArgs @{ script = $readScript }
                        if ($respCheck.data.result.text -and $respCheck.data.result.text.Length -gt 0) {
                            $answerText = $respCheck.data.result.text
                            if ($answerText -match "READY") {
                                $hasAnswer = $true
                                break
                            }
                        }
                    }

                    Write-SessionStatus @{
                        phase = "MESSAGE_SENT"
                        sentSuccess = $sendResp.data.result.success
                        answer = $answerText
                        containsReady = ($answerText -match "READY")
                    }
                    Write-Host "Gemini Answer: $answerText (Contains READY: $hasAnswer)" -ForegroundColor Green
                }

                "TEST_HIDDEN_MODE" {
                    Write-Host "Switching to Hidden Mode (IsVisible = false)..." -ForegroundColor Yellow
                    $visOff = Invoke-HostCommand -Process $proc -Command "SET_VISIBILITY" -ExtraArgs @{ visible = $false }
                    Write-Host "Visibility switched: isVisible=$($visOff.data.isVisible)" -ForegroundColor Green

                    Start-Sleep -Seconds 1
                    $docHidden = Invoke-HostCommand -Process $proc -Command "GET_DOCUMENT_INFO"
                    $navHidden = Invoke-HostCommand -Process $proc -Command "GET_NAVIGATION_STATUS"

                    Write-SessionStatus @{
                        phase = "HIDDEN_MODE_VERIFIED"
                        isVisible = $visOff.data.isVisible
                        url = $docHidden.data.href
                        title = $docHidden.data.title
                        readyState = $docHidden.data.readyState
                    }
                    Write-Host "Hidden mode verified: URL=$($docHidden.data.href), Title=$($docHidden.data.title)" -ForegroundColor Green
                }

                "EXIT" {
                    Write-Host "Closing session and exiting..." -ForegroundColor Yellow
                    $null = Invoke-HostCommand -Process $proc -Command "CLOSE"
                    $running = $false
                }

                default {
                    Write-Warning "Unknown action: $actionRaw"
                }
            }
        }
    }

} catch {
    Write-Host "FATAL ERROR in session controller: $_" -ForegroundColor Red
    Write-Host $_.ScriptStackTrace -ForegroundColor Red
} finally {
    if ($proc -and -not $proc.HasExited) {
        try {
            $null = Invoke-HostCommand -Process $proc -Command "CLOSE"
        } catch {}
        Start-Sleep -Milliseconds 500
        if (-not $proc.HasExited) { $proc.Kill() }
    }
    Write-Host "Interactive WebView2 Session Controller completed." -ForegroundColor Cyan
}
