[CmdletBinding()]
param()

$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# Make visible
$proc.StandardInput.WriteLine('{"requestId":"1","command":"SET_VISIBILITY","visible":true}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# Navigate to https://gemini.google.com/
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

Write-Host "Diagnostic window is open at https://gemini.google.com/." -ForegroundColor Green
Write-Host "Please look at the window and click 'Начать чат с Gemini' if required." -ForegroundColor Yellow
Write-Host "Window will remain open for 60 seconds (or press Ctrl+C to finish)..."

Start-Sleep -Seconds 60

$proc.StandardInput.WriteLine('{"requestId":"3","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
