$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
Write-Host "Navigating to https://gemini.google.com/app..."
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$nav = $proc.StandardOutput.ReadLine()
Write-Host "NAV: $nav"

Start-Sleep -Seconds 6

# 3. Document info
$proc.StandardInput.WriteLine('{"requestId":"3","command":"GET_DOCUMENT_INFO"}')
$proc.StandardInput.Flush()
$doc = $proc.StandardOutput.ReadLine()
Write-Host "DOC: $doc"

# 4. Deep DOM Probe
$probeScript = @'
JSON.stringify((function() {
    function getSummary(el) {
        if (!el) return null;
        return {
            tag: el.tagName,
            id: el.id || null,
            className: el.className || null,
            role: el.getAttribute('role'),
            ariaLabel: el.getAttribute('aria-label'),
            contentEditable: el.getAttribute('contenteditable'),
            disabled: el.disabled,
            type: el.getAttribute('type'),
            childrenCount: el.children.length
        };
    }

    // Input targets
    var richTextarea = document.querySelector('rich-textarea');
    var qlEditor = document.querySelector('.ql-editor');
    var contentEditable = document.querySelector('[contenteditable="true"]');
    var textarea = document.querySelector('textarea');
    var pInput = document.querySelector('p');

    // Buttons
    var buttons = Array.from(document.querySelectorAll('button')).map(function(b) {
        return {
            aria: b.getAttribute('aria-label'),
            className: b.className,
            text: (b.innerText || '').trim().substring(0, 40),
            disabled: b.disabled
        };
    }).filter(function(b) {
        return b.aria || b.text || (b.className && b.className.indexOf('send') !== -1);
    });

    // Message containers / History elements
    var messageElements = Array.from(document.querySelectorAll('[data-test-id], message-content, .model-response-text, user-query, model-response')).map(function(m) {
        return {
            tag: m.tagName,
            testId: m.getAttribute('data-test-id'),
            className: m.className,
            textSample: (m.innerText || '').trim().substring(0, 50)
        };
    });

    return {
        url: window.location.href,
        title: document.title,
        inputs: {
            richTextarea: getSummary(richTextarea),
            qlEditor: getSummary(qlEditor),
            contentEditable: getSummary(contentEditable),
            textarea: getSummary(textarea)
        },
        buttons: buttons.slice(0, 20),
        messageElements: messageElements.slice(0, 10)
    };
})())
'@

$cmd = @{
    requestId = "4"
    command = "EXECUTE_SCRIPT"
    script = $probeScript
    timeoutMs = 15000
} | ConvertTo-Json -Compress

$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$res = $proc.StandardOutput.ReadLine()
Write-Host "DOM_PROBE: $res"

$proc.StandardInput.WriteLine('{"requestId":"5","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
