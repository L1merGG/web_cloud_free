$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

# Get full text and messages
$proc.StandardInput.WriteLine('{"requestId":"3","command":"GET_PAGE_TEXT","maxLength":4000}')
$proc.StandardInput.Flush()
$pt = $proc.StandardOutput.ReadLine()
[System.IO.File]::WriteAllText("D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\diagnostics\full-chat-text.txt", $pt, [System.Text.Encoding]::UTF8)

$inspect = @'
JSON.stringify((function() {
    var turns = Array.from(document.querySelectorAll('*')).map(el => {
        var cls = el.className || '';
        var tn = el.tagName.toLowerCase();
        if (cls.indexOf('model-response') !== -1 || tn.indexOf('model-response') !== -1 || cls.indexOf('response-content') !== -1 || tn === 'message-content') {
            return {
                tag: el.tagName,
                cls: el.className,
                text: (el.innerText || '').trim()
            };
        }
        return null;
    }).filter(Boolean);

    return {
        count: turns.length,
        items: turns
    };
})())
'@

$cmd = @{ requestId = "4"; command = "EXECUTE_SCRIPT"; script = $inspect } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$res = $proc.StandardOutput.ReadLine()
[System.IO.File]::WriteAllText("D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\diagnostics\chat-turn-inspect.json", $res, [System.Text.Encoding]::UTF8)

$proc.StandardInput.WriteLine('{"requestId":"5","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
