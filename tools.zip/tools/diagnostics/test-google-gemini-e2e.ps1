<#
.SYNOPSIS
    Antigooglity WebView2 - Google Sign-In & Gemini E2E Diagnostic Runner
.DESCRIPTION
    Launches AntigooglityWebView2Host in visible diagnostic mode to verify:
    1. Google Sign-In compatibility with WebView2 (and checks for "This browser or app may not be secure").
    2. Session persistence across host restarts using the dedicated profile.
    3. Gemini interface availability and DOM interactivity.
    4. Test message sending and response generation.
    5. Hidden mode execution (switching visibility to false and testing background DOM/JS execution).
#>

[CmdletBinding()]
param(
    [switch]$SkipAuthCheck,
    [switch]$HiddenModeOnly
)

$ErrorActionPreference = "Stop"

# Ensure DOTNET_ROOT is available
if (-not $env:DOTNET_ROOT) {
    $dotnetDefault = "$env:LOCALAPPDATA\Microsoft\dotnet"
    if (Test-Path $dotnetDefault) {
        $env:DOTNET_ROOT = $dotnetDefault
        $env:PATH = "$dotnetDefault;$env:PATH"
    }
}

$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"
if (-not (Test-Path $hostExe)) {
    throw "Host executable not found at: $hostExe"
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " Antigooglity WebView2: Google Sign-In & Gemini Diagnostic" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "Executable: $hostExe"
Write-Host "Profile:    $env:LOCALAPPDATA\Antigooglity\webview2-profile"
Write-Host ""

function Start-WebView2Host {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $hostExe
    $psi.UseShellExecute = $false
    $psi.RedirectStandardInput = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.StandardOutputEncoding = [System.Text.Encoding]::UTF8
    $psi.StandardErrorEncoding = [System.Text.Encoding]::UTF8
    $psi.CreateNoWindow = $true

    if ($env:DOTNET_ROOT) {
        $psi.EnvironmentVariables["DOTNET_ROOT"] = $env:DOTNET_ROOT
    }

    $proc = [System.Diagnostics.Process]::Start($psi)

    # Background error reader
    $errJob = [powershell]::Create().AddScript({
        param($process)
        while (-not $process.HasExited) {
            $line = $process.StandardError.ReadLine()
            if ($line) {
                [Console]::ForegroundColor = [ConsoleColor]::DarkGray
                [Console]::Error.WriteLine("  $line")
                [Console]::ResetColor()
            }
        }
    }).AddArgument($proc)
    $null = $errJob.BeginInvoke()

    return $proc
}

$script:reqCounter = 0

function Invoke-HostCommand {
    param(
        [Parameter(Mandatory=$true)] $Process,
        [Parameter(Mandatory=$true)] [string] $Command,
        [hashtable] $ExtraArgs = @{},
        [int] $TimeoutSec = 30
    )

    $script:reqCounter++
    $reqId = "req-$($script:reqCounter)"

    $payload = @{
        requestId = $reqId
        command = $Command
    }
    foreach ($k in $ExtraArgs.Keys) {
        $payload[$k] = $ExtraArgs[$k]
    }

    $json = $payload | ConvertTo-Json -Compress
    $Process.StandardInput.WriteLine($json)
    $Process.StandardInput.Flush()

    # The host replies synchronously on stdout per command
    $readTask = $Process.StandardOutput.ReadLineAsync()
    if (-not $readTask.Wait($TimeoutSec * 1000)) {
        throw "Command '$Command' (reqId: $reqId) timed out after $TimeoutSec seconds"
    }

    $line = $readTask.Result
    if ($null -eq $line) {
        throw "Host process stdout reached EOF while waiting for command '$Command'"
    }

    return ($line | ConvertFrom-Json)
}

# -------------------------------------------------------------
# STEP 1: Start Host & Enable Diagnostic Window
# -------------------------------------------------------------
Write-Host "`n>>> [STEP 1] Starting WebView2 Host..." -ForegroundColor Yellow
$proc = Start-WebView2Host
Start-Sleep -Milliseconds 800

$ping = Invoke-HostCommand -Process $proc -Command "PING"
Write-Host "Host responded to PING: $($ping.data.message), Runtime: $($ping.data.runtimeVersion)" -ForegroundColor Green

Write-Host "Switching to Visible Diagnostic Mode..." -ForegroundColor Yellow
$visResp = Invoke-HostCommand -Process $proc -Command "SET_VISIBILITY" -ExtraArgs @{ visible = $true }
Write-Host "Visibility response: isVisible=$($visResp.data.isVisible), formVisible=$($visResp.data.formVisible)" -ForegroundColor Green

# -------------------------------------------------------------
# STEP 2: Navigate to Google Sign-In
# -------------------------------------------------------------
Write-Host "`n>>> [STEP 2] Navigating to https://accounts.google.com/..." -ForegroundColor Yellow
$nav = Invoke-HostCommand -Process $proc -Command "NAVIGATE" -ExtraArgs @{ url = "https://accounts.google.com/"; timeoutMs = 30000 }
Write-Host "Navigation completed: isSuccess=$($nav.data.isSuccess), url=$($nav.data.url), HTTP=$($nav.data.httpStatusCode)" -ForegroundColor Green

Start-Sleep -Seconds 2

$docInfo = Invoke-HostCommand -Process $proc -Command "GET_DOCUMENT_INFO"
Write-Host "Document Info:" -ForegroundColor Cyan
Write-Host "  Title:     $($docInfo.data.title)"
Write-Host "  Ready:     $($docInfo.data.readyState)"
Write-Host "  URL:       $($docInfo.data.href)"

$pageText = Invoke-HostCommand -Process $proc -Command "GET_PAGE_TEXT" -ExtraArgs @{ maxLength = 500 }
Write-Host "Page Text Preview (first 500 chars):" -ForegroundColor DarkGray
Write-Host "  $($pageText.data.text -replace "`r?`n", " ")" -ForegroundColor DarkGray

# Check for input field presence
$detectScript = @'
(function() {
    return {
        hasEmailInput: !!document.querySelector('input[type="email"]'),
        title: document.title,
        bodyLength: document.body ? document.body.innerText.length : 0
    };
})()
'@

$inputCheck = Invoke-HostCommand -Process $proc -Command "EXECUTE_SCRIPT" -ExtraArgs @{ script = $detectScript }
Write-Host "Form element detection: $($inputCheck.data.rawResult)" -ForegroundColor Cyan

# -------------------------------------------------------------
# STEP 3: Check for Google Security Block
# -------------------------------------------------------------
$fullText = $pageText.data.text
if ($fullText -match "This browser or app may not be secure" -or $fullText -match "небезопасн" -or $fullText -match "Couldn't sign you in") {
    Write-Host "`n[ALERT] Google displayed a security warning on the initial page!" -ForegroundColor Red
} else {
    Write-Host "`n[STATUS] Standard Google Sign-In form is displayed and active." -ForegroundColor Green
}

Write-Host "`n------------------------------------------------------------" -ForegroundColor Yellow
Write-Host " Diagnostic window is active." -ForegroundColor Yellow
Write-Host " Closing host now for automated test check..." -ForegroundColor Yellow
$closeResp = Invoke-HostCommand -Process $proc -Command "CLOSE"
Write-Host "Host closed cleanly: $($closeResp.data.closed)" -ForegroundColor Green
