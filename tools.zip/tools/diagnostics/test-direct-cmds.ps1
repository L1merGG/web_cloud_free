$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

$proc.StandardInput.WriteLine('{"requestId":"1","command":"NAVIGATE","url":"https://accounts.google.com/"}')
$proc.StandardInput.Flush()
$nav = $proc.StandardOutput.ReadLine()
Write-Host "Nav: $nav"

$proc.StandardInput.WriteLine('{"requestId":"2","command":"GET_DOCUMENT_INFO"}')
$proc.StandardInput.Flush()
$doc = $proc.StandardOutput.ReadLine()
Write-Host "Doc: $doc"

$proc.StandardInput.WriteLine('{"requestId":"3","command":"GET_PAGE_TEXT","maxLength":1000}')
$proc.StandardInput.Flush()
$txt = $proc.StandardOutput.ReadLine()
Write-Host "Txt: $txt"

$proc.StandardInput.WriteLine('{"requestId":"4","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Exit code: $($proc.ExitCode)"
