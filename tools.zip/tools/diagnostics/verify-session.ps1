$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$ping = $proc.StandardOutput.ReadLine()
Write-Host "PING: $ping"

# 2. Check profile persistence: Navigate to Google Account dashboard
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://myaccount.google.com/","timeoutMs":45000}')
$proc.StandardInput.Flush()
$nav = $proc.StandardOutput.ReadLine()
Write-Host "NAVIGATE: $nav"

Start-Sleep -Seconds 2

# 3. Document info
$proc.StandardInput.WriteLine('{"requestId":"3","command":"GET_DOCUMENT_INFO"}')
$proc.StandardInput.Flush()
$doc = $proc.StandardOutput.ReadLine()
Write-Host "DOC_INFO: $doc"

# 4. Page text preview
$proc.StandardInput.WriteLine('{"requestId":"4","command":"GET_PAGE_TEXT","maxLength":1500}')
$proc.StandardInput.Flush()
$txt = $proc.StandardOutput.ReadLine()
Write-Host "PAGE_TEXT: $txt"

$proc.StandardInput.WriteLine('{"requestId":"5","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Exit code: $($proc.ExitCode)"
