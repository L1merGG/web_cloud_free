@echo off
setlocal
cd /d "%~dp0\..\.."
echo ========================================================
echo  Antigooglity WebView2 - Gemini Interface Opener
echo ========================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run-diagnostic-direct.ps1"
pause
