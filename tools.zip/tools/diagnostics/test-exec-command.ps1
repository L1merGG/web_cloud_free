$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

# Test: get editor innerHTML
$s1 = "document.querySelector('.ql-editor').innerHTML"
$c1 = @{ requestId = "3"; command = "EXECUTE_SCRIPT"; script = $s1 } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($c1)
$proc.StandardInput.Flush()
$r1 = $proc.StandardOutput.ReadLine()
Write-Host "r1: $r1"

# Test: insert text with document.execCommand('insertText', false, 'test')
$s2 = @"
(function() {
    var editor = document.querySelector('.ql-editor');
    editor.focus();
    var ok = document.execCommand('insertText', false, 'Привет от WebView2!');
    return { ok: ok, text: editor.innerText.trim() };
})()
"@
$c2 = @{ requestId = "4"; command = "EXECUTE_SCRIPT"; script = $s2 } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($c2)
$proc.StandardInput.Flush()
$r2 = $proc.StandardOutput.ReadLine()
Write-Host "r2: $r2"

# Test: look for send button after typing
$s3 = @"
(function() {
    var btn = document.querySelector('button[aria-label*=\"Отправить\"]') ||
              document.querySelector('button[aria-label*=\"Send\"]') ||
              document.querySelector('.send-button') ||
              document.querySelector('button.send-button-container');
    if (btn) {
        return { found: true, aria: btn.getAttribute('aria-label'), className: btn.className, disabled: btn.disabled };
    }
    // Search all buttons
    var all = Array.from(document.querySelectorAll('button')).map(function(b) {
        return { aria: b.getAttribute('aria-label'), cls: b.className };
    }).filter(function(b) { return b.aria && (b.aria.indexOf('тправ') !== -1 || b.aria.indexOf('Send') !== -1); });
    return { found: false, matches: all };
})()
"@
$c3 = @{ requestId = "5"; command = "EXECUTE_SCRIPT"; script = $s3 } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($c3)
$proc.StandardInput.Flush()
$r3 = $proc.StandardOutput.ReadLine()
Write-Host "r3: $r3"

$proc.StandardInput.WriteLine('{"requestId":"6","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
