$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. Inspect button details on https://gemini.google.com/
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

$script = @'
JSON.stringify((function() {
    var btn = Array.from(document.querySelectorAll('button')).find(function(b) {
        return (b.innerText || '').indexOf('Начать чат с Gemini') !== -1;
    });
    if (!btn) return { found: false };

    var rect = btn.getBoundingClientRect();
    var parentTag = btn.parentElement ? btn.parentElement.tagName : null;
    var parentClass = btn.parentElement ? btn.parentElement.className : null;
    var onclick = btn.getAttribute('onclick');
    var jsaction = btn.getAttribute('jsaction');

    // Dispatch real pointer and click events
    btn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    btn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
    btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

    return {
        found: true,
        text: btn.innerText,
        rect: { x: rect.x, y: rect.y, w: rect.width, h: rect.height },
        parentTag: parentTag,
        parentClass: parentClass,
        jsaction: jsaction
    };
})())
'@

$cmd = @{
    requestId = "3"
    command = "EXECUTE_SCRIPT"
    script = $script
    timeoutMs = 15000
} | ConvertTo-Json -Compress

$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$res = $proc.StandardOutput.ReadLine()
Write-Host "BUTTON_CLICK_RESULT: $res"

Start-Sleep -Seconds 6

$proc.StandardInput.WriteLine('{"requestId":"4","command":"GET_DOCUMENT_INFO"}')
$proc.StandardInput.Flush()
$doc = $proc.StandardOutput.ReadLine()
Write-Host "DOC_INFO: $doc"

$proc.StandardInput.WriteLine('{"requestId":"5","command":"GET_PAGE_TEXT","maxLength":1000}')
$proc.StandardInput.Flush()
$txt = $proc.StandardOutput.ReadLine()
Write-Host "TXT: $txt"

$proc.StandardInput.WriteLine('{"requestId":"6","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
