$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$ping = $proc.StandardOutput.ReadLine()
Write-Host "PING: $ping"

# 2. Navigate to https://gemini.google.com/
Write-Host "Navigating to https://gemini.google.com/..."
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$nav = $proc.StandardOutput.ReadLine()
Write-Host "NAVIGATE: $nav"

# Let single page app hydrate
Start-Sleep -Seconds 5

# 3. Document info
$proc.StandardInput.WriteLine('{"requestId":"3","command":"GET_DOCUMENT_INFO"}')
$proc.StandardInput.Flush()
$doc = $proc.StandardOutput.ReadLine()
Write-Host "DOC_INFO: $doc"

# 4. Page text preview
$proc.StandardInput.WriteLine('{"requestId":"4","command":"GET_PAGE_TEXT","maxLength":2000}')
$proc.StandardInput.Flush()
$txt = $proc.StandardOutput.ReadLine()
Write-Host "PAGE_TEXT: $txt"

# 5. DOM inspection for prompt input field & send button
$inspectScript = @'
(function() {
    var richText = document.querySelector('rich-textarea');
    var pInput = document.querySelector('.ql-editor') || document.querySelector('[contenteditable="true"]') || document.querySelector('textarea');
    var sendBtn = document.querySelector('button[aria-label*="Отправить"]') ||
                  document.querySelector('button[aria-label*="Send"]') ||
                  document.querySelector('.send-button');
    return {
        hasRichTextarea: !!richText,
        hasEditor: !!pInput,
        editorTag: pInput ? pInput.tagName : null,
        editorClass: pInput ? pInput.className : null,
        hasSendButton: !!sendBtn,
        sendButtonAria: sendBtn ? sendBtn.getAttribute('aria-label') : null,
        sendButtonDisabled: sendBtn ? sendBtn.disabled : null,
        title: document.title,
        url: window.location.href
    };
})()
'@

$cmd = @{
    requestId = "5"
    command = "EXECUTE_SCRIPT"
    script = $inspectScript
    timeoutMs = 15000
} | ConvertTo-Json -Compress

$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$domInspect = $proc.StandardOutput.ReadLine()
Write-Host "DOM_INSPECT: $domInspect"

$proc.StandardInput.WriteLine('{"requestId":"6","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
