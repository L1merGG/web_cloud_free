$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

$testScript = @'
(function() {
    var slf = document.querySelector('.single-line-format');
    if (!slf) return { error: 'No single-line-format' };

    var parent = slf.parentElement;
    var allButtons = Array.from(parent.querySelectorAll('button, [role="button"], mat-icon')).map(b => {
        return {
            tag: b.tagName,
            role: b.getAttribute('role'),
            aria: b.getAttribute('aria-label'),
            cls: b.className,
            text: (b.innerText || '').trim()
        };
    });

    return {
        parentTag: parent.tagName,
        parentCls: parent.className,
        buttons: allButtons
    };
})()
'@

$cmd = @{ requestId = "10"; command = "EXECUTE_SCRIPT"; script = $testScript } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$res = $proc.StandardOutput.ReadLine()
Write-Host "INPUT_AREA_BUTTONS: $res"

$proc.StandardInput.WriteLine('{"requestId":"11","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
