$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

# Step 1: focus & insert prompt: 'Ответь одной короткой фразой: WebView2 успешно получает сообщения, если ты видишь этот запрос'
$prompt = [System.Text.Encoding]::UTF8.GetString([System.Text.Encoding]::UTF8.GetBytes("Ответь одной короткой фразой: WebView2 успешно получает сообщения, если ты видишь этот запрос"))

$cmd1 = @{
    requestId = "10"
    command = "EXECUTE_SCRIPT"
    script = @"
document.querySelector('.ql-editor').focus();
document.execCommand('insertText', false, '$prompt');
document.querySelector('.ql-editor').dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
'sent'
"@
} | ConvertTo-Json -Compress

$proc.StandardInput.WriteLine($cmd1)
$proc.StandardInput.Flush()
Write-Host "Send result: $($proc.StandardOutput.ReadLine())"

# Wait and poll for response
$foundAnswer = $false

for ($i = 0; $i -lt 15; $i++) {
    Start-Sleep -Seconds 2

    $proc.StandardInput.WriteLine('{"requestId":"pt","command":"GET_PAGE_TEXT","maxLength":2000}')
    $proc.StandardInput.Flush()
    $ptRes = $proc.StandardOutput.ReadLine()
    Write-Host "Poll [$i] PageText: $ptRes"

    if ($ptRes -match "WebView2" -and $ptRes -match "успешно") {
        $foundAnswer = $true
        break
    }
}

$proc.StandardInput.WriteLine('{"requestId":"close","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done, foundAnswer: $foundAnswer"
