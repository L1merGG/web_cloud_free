$xmlPath = 'C:\Users\L1merGG\.gemini\antigravity-acp\brain\8c556bc9-bfe9-4aa7-9b60-bf64f56bb154\scratch\docx_unpacked\word\document.xml'
$raw = Get-Content -Path $xmlPath -Raw -Encoding UTF8
$matches = [regex]::Matches($raw, '<w:t[^>]*>(.*?)</w:t>')
$sb = New-Object System.Text.StringBuilder
foreach ($m in $matches) {
    [void]$sb.AppendLine($m.Groups[1].Value)
}
$outPath = 'C:\Users\L1merGG\.gemini\antigravity-acp\brain\8c556bc9-bfe9-4aa7-9b60-bf64f56bb154\scratch\docx_text.txt'
[System.IO.File]::WriteAllText($outPath, $sb.ToString(), [System.Text.Encoding]::UTF8)
Write-Host "Extracted text to $outPath"
