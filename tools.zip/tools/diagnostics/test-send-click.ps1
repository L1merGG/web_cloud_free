$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

# Step 1: Insert text and click Send Button
$clickScript = @'
(function() {
    var editor = document.querySelector('.ql-editor');
    if (!editor) return { error: 'No editor' };
    editor.focus();
    document.execCommand('insertText', false, 'Ответь одной короткой фразой: WebView2 успешно получает сообщения, если ты видишь этот запрос');
    editor.dispatchEvent(new Event('input', { bubbles: true }));

    var sendBtn = document.querySelector('button[aria-label*="Отправить"]') ||
                  document.querySelector('button[aria-label*="Send"]');
    if (!sendBtn) return { error: 'No sendBtn' };

    sendBtn.click();
    return {
        clicked: true,
        aria: sendBtn.getAttribute('aria-label')
    };
})()
'@

$cmd = @{ requestId = "10"; command = "EXECUTE_SCRIPT"; script = $clickScript } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$resClick = $proc.StandardOutput.ReadLine()
Write-Host "SEND_CLICK_RESULT: $resClick"

# Poll for model response
for ($i = 0; $i -lt 15; $i++) {
    Start-Sleep -Seconds 2

    # Check for responses in DOM
    $checkScript = @'
JSON.stringify((function() {
    var turns = Array.from(document.querySelectorAll('message-content, .model-response-text, model-response, .response-content, .markdown')).map(el => (el.innerText || '').trim()).filter(Boolean);
    var isGenerating = !!document.querySelector('.generating, mat-progress-spinner, [aria-label*="Остановить"], [aria-label*="Stop"]');
    return {
        turns: turns,
        isGenerating: isGenerating
    };
})())
'@
    $cmdCheck = @{ requestId = "poll-$i"; command = "EXECUTE_SCRIPT"; script = $checkScript } | ConvertTo-Json -Compress
    $proc.StandardInput.WriteLine($cmdCheck)
    $proc.StandardInput.Flush()
    $resPoll = $proc.StandardOutput.ReadLine()
    Write-Host "Poll [$i]: $resPoll"

    if ($resPoll -match "WebView2" -and $resPoll -notmatch "Ваш запрос") {
        Write-Host "FOUND ANSWER!" -ForegroundColor Green
        break
    }
}

$proc.StandardInput.WriteLine('{"requestId":"11","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
