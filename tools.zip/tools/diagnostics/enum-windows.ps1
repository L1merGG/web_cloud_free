Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Collections.Generic;

public class WinEnum {
    public delegate bool EnumThreadDelegate(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool EnumThreadWindows(int dwThreadId, EnumThreadDelegate lpfn, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    [DllImport("user32.dll")]
    public static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left, Top, Right, Bottom; }

    public static List<string> GetWindowsForProcess(int pid) {
        var list = new List<string>();
        var proc = System.Diagnostics.Process.GetProcessById(pid);
        foreach (System.Diagnostics.ProcessThread thread in proc.Threads) {
            EnumThreadWindows(thread.Id, (hWnd, lParam) => {
                var sb = new StringBuilder(256);
                GetWindowText(hWnd, sb, 256);
                var vis = IsWindowVisible(hWnd);
                RECT r;
                GetWindowRect(hWnd, out r);
                list.Add(string.Format("HWND: 0x{0:X}, Vis: {1}, Title: '{2}', Rect: ({3},{4},{5},{6})", 
                    hWnd.ToInt64(), vis, sb.ToString(), r.Left, r.Top, r.Right, r.Bottom));
                return true;
            }, IntPtr.Zero);
        }
        return list;
    }
}
"@ -ErrorAction SilentlyContinue

$p = Get-Process -Name AntigooglityWebView2Host -ErrorAction SilentlyContinue
if ($p) {
    [WinEnum]::GetWindowsForProcess($p.Id) | ForEach-Object { Write-Host $_ }
} else {
    Write-Host "Process not found"
}
