$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

# 3. Simulate typing text into the editor and observing the send button
$typeScript = @'
JSON.stringify((function() {
    var editor = document.querySelector('.ql-editor') || document.querySelector('[contenteditable="true"]');
    if (!editor) return { error: 'editor not found' };

    editor.focus();
    // Simulate user typing
    editor.innerHTML = '<p>Test probe</p>';
    editor.dispatchEvent(new Event('input', { bubbles: true }));
    editor.dispatchEvent(new Event('change', { bubbles: true }));

    // Look for all buttons inside or near the input area
    var inputContainer = editor.closest('input-area') || editor.closest('.input-area-container') || editor.parentElement.parentElement;
    var allButtons = Array.from(document.querySelectorAll('button')).map(function(b) {
        return {
            aria: b.getAttribute('aria-label'),
            className: b.className,
            text: (b.innerText || '').trim(),
            disabled: b.disabled,
            matIcon: (b.querySelector('mat-icon') ? b.querySelector('mat-icon').innerText : null)
        };
    }).filter(function(b) {
        return (b.aria && (b.aria.indexOf('тправ') !== -1 || b.aria.indexOf('Send') !== -1)) ||
               (b.className && b.className.indexOf('send') !== -1) ||
               (b.matIcon && b.matIcon.indexOf('send') !== -1);
    });

    return {
        editorText: editor.innerText,
        sendButtons: allButtons
    };
})())
'@

$cmd = @{
    requestId = "3"
    command = "EXECUTE_SCRIPT"
    script = $typeScript
    timeoutMs = 15000
} | ConvertTo-Json -Compress

$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$res = $proc.StandardOutput.ReadLine()
Write-Host "SEND_BUTTON_DETECTION: $res"

$proc.StandardInput.WriteLine('{"requestId":"4","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
