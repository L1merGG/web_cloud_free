$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

$testScript = @'
(function() {
    var editor = document.querySelector('.ql-editor');
    if (!editor) return { error: 'No editor' };

    // Get parent hierarchy
    var parents = [];
    var cur = editor;
    while (cur && parents.length < 5) {
        parents.push({
            tag: cur.tagName,
            cls: cur.className,
            childrenCount: cur.children.length,
            childTags: Array.from(cur.children).map(c => c.tagName + '.' + c.className.substring(0, 20))
        });
        cur = cur.parentElement;
    }

    return {
        editorParent: parents
    };
})()
'@

$cmd = @{ requestId = "10"; command = "EXECUTE_SCRIPT"; script = $testScript } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$res = $proc.StandardOutput.ReadLine()
Write-Host "EDITOR_HIERARCHY: $res"

$proc.StandardInput.WriteLine('{"requestId":"11","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
