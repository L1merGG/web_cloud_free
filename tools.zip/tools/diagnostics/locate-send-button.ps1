$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

# Step 1: focus & insert text via execCommand + input event
$testScript = @'
(function() {
    var editor = document.querySelector('.ql-editor');
    if (!editor) return { error: 'No editor' };
    editor.focus();
    document.execCommand('insertText', false, 'Test query text');
    editor.dispatchEvent(new Event('input', { bubbles: true }));

    var allDescendants = Array.from(document.querySelectorAll('button, [role="button"], mat-icon')).map(function(el) {
        return {
            tag: el.tagName,
            role: el.getAttribute('role'),
            aria: el.getAttribute('aria-label'),
            className: el.className,
            text: (el.innerText || '').trim()
        };
    }).filter(function(x) {
        return (x.aria && (x.aria.indexOf('Send') !== -1 || x.aria.indexOf('\u043E\u0442\u043F\u0440\u0430\u0432') !== -1)) ||
               (x.className && x.className.indexOf('send') !== -1) ||
               x.text === 'send' || x.aria === 'send';
    });

    return {
        editorText: editor.innerText.trim(),
        matches: allDescendants
    };
})()
'@

$cmd = @{ requestId = "10"; command = "EXECUTE_SCRIPT"; script = $testScript } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$res = $proc.StandardOutput.ReadLine()
Write-Host "MATCHING_ELEMENTS: $res"

$proc.StandardInput.WriteLine('{"requestId":"11","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
