$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. NAVIGATE to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()
Start-Sleep -Seconds 5

# Step 1: focus & insert text
$cmd1 = @{ requestId = "10"; command = "EXECUTE_SCRIPT"; script = "document.querySelector('.ql-editor').focus(); document.execCommand('insertText', false, 'Тестовый запрос');" } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmd1)
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

Start-Sleep -Milliseconds 500

# Step 2: find all buttons with aria-label
$cmd2 = @{ requestId = "11"; command = "EXECUTE_SCRIPT"; script = "Array.from(document.querySelectorAll('button')).map(b => b.getAttribute('aria-label')).filter(Boolean)" } | ConvertTo-Json -Compress
$proc.StandardInput.WriteLine($cmd2)
$proc.StandardInput.Flush()
$res2 = $proc.StandardOutput.ReadLine()
Write-Host "Buttons aria-labels: $res2"

$proc.StandardInput.WriteLine('{"requestId":"12","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
