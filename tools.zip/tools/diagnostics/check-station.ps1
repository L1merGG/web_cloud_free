Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class StationCheck {
    [DllImport("user32.dll")] public static extern IntPtr GetProcessWindowStation();
    [DllImport("user32.dll")] public static extern IntPtr GetThreadDesktop(int dwThreadId);
    [DllImport("kernel32.dll")] public static extern int GetCurrentThreadId();
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool GetUserObjectInformation(IntPtr hObj, int nIndex, StringBuilder pvInfo, int nLength, out int lpnLengthNeeded);
    public static string GetStationName() {
        var h = GetProcessWindowStation();
        var sb = new StringBuilder(256);
        int needed;
        GetUserObjectInformation(h, 2, sb, 256, out needed);
        return sb.ToString();
    }
    public static string GetDesktopName() {
        var h = GetThreadDesktop(GetCurrentThreadId());
        var sb = new StringBuilder(256);
        int needed;
        GetUserObjectInformation(h, 2, sb, 256, out needed);
        return sb.ToString();
    }
}
"@

Write-Host "WindowStation: $([StationCheck]::GetStationName())"
Write-Host "Desktop: $([StationCheck]::GetDesktopName())"
