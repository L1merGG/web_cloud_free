$env:DOTNET_ROOT = "$env:LOCALAPPDATA\Microsoft\dotnet"
$hostExe = "D:\Programs\IntelliJ IDEA 2026.2.3\Antigooglity\tools\webview2-host\bin\Release\net8.0-windows\AntigooglityWebView2Host.exe"

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $hostExe
$psi.UseShellExecute = $false
$psi.RedirectStandardInput = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$proc = [System.Diagnostics.Process]::Start($psi)
Start-Sleep -Milliseconds 800

# 1. PING
$proc.StandardInput.WriteLine('{"requestId":"1","command":"PING"}')
$proc.StandardInput.Flush()
$null = $proc.StandardOutput.ReadLine()

# 2. Navigate to https://gemini.google.com/app
$proc.StandardInput.WriteLine('{"requestId":"2","command":"NAVIGATE","url":"https://gemini.google.com/app","timeoutMs":45000}')
$proc.StandardInput.Flush()
$nav = $proc.StandardOutput.ReadLine()
Write-Host "NAV: $nav"

Start-Sleep -Seconds 6

# 3. Document info
$proc.StandardInput.WriteLine('{"requestId":"3","command":"GET_DOCUMENT_INFO"}')
$proc.StandardInput.Flush()
$doc = $proc.StandardOutput.ReadLine()
Write-Host "DOC: $doc"

# 4. Check links/buttons on page
$script = @'
JSON.stringify((function() {
    var buttons = Array.from(document.querySelectorAll('button, a')).map(function(b) {
        return {
            tag: b.tagName,
            text: (b.innerText || '').trim().substring(0, 50),
            href: b.getAttribute('href'),
            aria: b.getAttribute('aria-label')
        };
    }).filter(function(x) { return x.text || x.aria; });

    return {
        url: window.location.href,
        title: document.title,
        buttonCount: buttons.length,
        items: buttons.slice(0, 15)
    };
})())
'@

$cmd = @{
    requestId = "4"
    command = "EXECUTE_SCRIPT"
    script = $script
    timeoutMs = 15000
} | ConvertTo-Json -Compress

$proc.StandardInput.WriteLine($cmd)
$proc.StandardInput.Flush()
$res = $proc.StandardOutput.ReadLine()
Write-Host "BUTTONS: $res"

# 5. Check if clicking "Начать чат с Gemini" or similar navigation is needed
$clickScript = @'
JSON.stringify((function() {
    var startBtn = Array.from(document.querySelectorAll('button, a')).find(function(b) {
        return (b.innerText && b.innerText.indexOf('Начать чат') !== -1) ||
               (b.innerText && b.innerText.indexOf('Start chat') !== -1);
    });
    if (startBtn) {
        var href = startBtn.getAttribute('href');
        startBtn.click();
        return { clicked: true, text: startBtn.innerText, href: href };
    }
    return { clicked: false };
})())
'@

$cmdClick = @{
    requestId = "5"
    command = "EXECUTE_SCRIPT"
    script = $clickScript
    timeoutMs = 15000
} | ConvertTo-Json -Compress

$proc.StandardInput.WriteLine($cmdClick)
$proc.StandardInput.Flush()
$resClick = $proc.StandardOutput.ReadLine()
Write-Host "CLICK_RESULT: $resClick"

Start-Sleep -Seconds 5

# 6. Check URL & doc info after click
$proc.StandardInput.WriteLine('{"requestId":"6","command":"GET_DOCUMENT_INFO"}')
$proc.StandardInput.Flush()
$docAfter = $proc.StandardOutput.ReadLine()
Write-Host "DOC_AFTER: $docAfter"

$proc.StandardInput.WriteLine('{"requestId":"7","command":"GET_PAGE_TEXT","maxLength":1500}')
$proc.StandardInput.Flush()
$txtAfter = $proc.StandardOutput.ReadLine()
Write-Host "TXT_AFTER: $txtAfter"

$proc.StandardInput.WriteLine('{"requestId":"8","command":"CLOSE"}')
$proc.StandardInput.Flush()
$proc.WaitForExit()
Write-Host "Done"
