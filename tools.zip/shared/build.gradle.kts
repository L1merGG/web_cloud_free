plugins {
    alias(libs.plugins.kotlinMultiplatform)
    alias(libs.plugins.composeMultiplatform)
    alias(libs.plugins.composeCompiler)
}

kotlin {
    jvm()
    sourceSets {
        commonMain.dependencies {
            implementation(libs.compose.runtime)
            implementation(libs.compose.foundation)
            implementation(libs.compose.material3)
            implementation(libs.compose.ui)
            implementation(libs.compose.components.resources)
            implementation(libs.compose.uiToolingPreview)
            implementation(libs.androidx.lifecycle.viewmodelCompose)
            implementation(libs.androidx.lifecycle.runtimeCompose)
        }
        commonTest.dependencies {
            implementation(libs.kotlin.test)
        }
        jvmMain.dependencies {
        }
    }
}

tasks.withType<Test> {
    maxHeapSize = "2048m"
}

tasks.register<Test>("geminiRealSmokeTest") {
    group = "verification"
    description = "Runs live Gemini smoke test against real authenticated WebView2 session"
    val jvmTestTask = tasks.named<Test>("jvmTest").get()
    classpath = jvmTestTask.classpath
    testClassesDirs = jvmTestTask.testClassesDirs
    systemProperty("antigooglity.gemini.real.smoke", "true")
    filter {
        includeTestsMatching("com.limer.antigooglity.webview2.gemini.GeminiRealSmokeTest.*")
    }
}
