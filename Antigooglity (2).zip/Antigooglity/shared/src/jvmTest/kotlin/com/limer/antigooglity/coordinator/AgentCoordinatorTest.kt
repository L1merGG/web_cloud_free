package com.limer.antigooglity.coordinator

import com.limer.antigooglity.model.ModelResponse
import com.limer.antigooglity.model.mock.MockModelAdapter
import com.limer.antigooglity.tools.ToolCall
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import java.nio.file.Files
import java.nio.file.Path
import kotlin.test.AfterTest
import kotlin.test.BeforeTest
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

class AgentCoordinatorTest {

    private lateinit var tempDir: Path
    private lateinit var otherDir: Path

    @BeforeTest
    fun setUp() {
        tempDir = Files.createTempDirectory("antigooglity-coord-test-").toRealPath()
        otherDir = Files.createTempDirectory("antigooglity-coord-other-").toRealPath()
    }

    @AfterTest
    fun tearDown() {
        tempDir.toFile().deleteRecursively()
        otherDir.toFile().deleteRecursively()
    }

    private fun createCoordinatorWithRealTools(
        workspacePath: Path,
        permissions: SecurityPermissions = SecurityPermissions(),
        modelAdapter: MockModelAdapter,
    ): AgentCoordinator {
        return AgentCoordinator(
            initialWorkspacePath = workspacePath,
            initialPermissions = permissions,
            scope = CoroutineScope(Dispatchers.Default),
            modelAdapterFactory = { modelAdapter },
            toolExecutorFactory = { ws, perm, app -> AgentFactory.createRealToolExecutor(ws, perm, app) },
        )
    }

    // 1. Управление состоянием выполнения
    @Test
    fun testExecutionStateTransitionsAndCompletion() = runBlocking {
        val mockAdapter = MockModelAdapter(
            ModelResponse(text = "Привет от модели!", toolCalls = emptyList())
        )
        val coordinator = AgentCoordinator(
            initialWorkspacePath = tempDir,
            scope = CoroutineScope(Dispatchers.Default),
            modelAdapterFactory = { mockAdapter },
        )

        assertEquals(ExecutionStatus.IDLE, coordinator.executionStatus.value)

        val job = coordinator.startTask("Скажи привет")
        assertTrue(coordinator.isRunning)

        job.join()

        assertEquals(ExecutionStatus.IDLE, coordinator.executionStatus.value)
        val activeConv = coordinator.conversations.value.first { it.id == coordinator.activeConversationId.value }
        assertEquals(2, activeConv.messages.size)
        assertEquals(UiMessageRole.USER, activeConv.messages[0].role)
        assertEquals("Скажи привет", activeConv.messages[0].text)
        assertEquals(UiMessageRole.ASSISTANT, activeConv.messages[1].role)
        assertEquals("Привет от модели!", activeConv.messages[1].text)
    }

    // 2. Обработка событий AgentEvent
    @Test
    fun testAgentEventHandling() = runBlocking {
        val toolCall = ToolCall(
            id = "c_write_file",
            name = "write_file",
            arguments = """{"path": "coord_test.txt", "content": "Coordinator Works"}""",
        )
        val mockAdapter = MockModelAdapter(
            ModelResponse(text = "Создаю файл...", toolCalls = listOf(toolCall)),
            ModelResponse(text = "Готово!", toolCalls = emptyList()),
        )

        val coordinator = createCoordinatorWithRealTools(
            workspacePath = tempDir,
            modelAdapter = mockAdapter,
        )

        val job = coordinator.startTask("Создай файл")
        job.join()

        val activeConv = coordinator.conversations.value.first { it.id == coordinator.activeConversationId.value }
        val assistantMsg = activeConv.messages.first { it.role == UiMessageRole.ASSISTANT }
        assertEquals("Готово!", assistantMsg.text)
        assertEquals(1, assistantMsg.toolExecutions.size)
        val toolExec = assistantMsg.toolExecutions.first()
        assertEquals("c_write_file", toolExec.toolCallId)
        assertEquals("write_file", toolExec.toolName)
        assertEquals(ToolStatus.SUCCESS, toolExec.status)
        val result = toolExec.result
        assertNotNull(result)
        assertTrue(result.success)
        assertTrue(Files.exists(tempDir.resolve("coord_test.txt")))
    }

    // 3. Отмена задачи
    @Test
    fun testTaskCancellation() = runBlocking {
        val sleepSource = """
            public class SleepAppCoord {
                public static void main(String[] args) throws Exception {
                    Thread.sleep(10000);
                }
            }
        """.trimIndent()
        Files.writeString(tempDir.resolve("SleepAppCoord.java"), sleepSource)

        val toolCall = ToolCall(
            id = "c_sleep",
            name = "execute_command",
            arguments = """{"command": "java", "args": ["SleepAppCoord.java"]}""",
        )
        val mockAdapter = MockModelAdapter(
            ModelResponse(text = "Запускаю долгий процесс...", toolCalls = listOf(toolCall)),
            ModelResponse(text = "Процесс завершён", toolCalls = emptyList()),
        )

        val coordinator = createCoordinatorWithRealTools(
            workspacePath = tempDir,
            modelAdapter = mockAdapter,
        )

        val job = coordinator.startTask("Запусти долгий процесс")
        for (i in 0 until 50) {
            if (coordinator.isRunning) break
            delay(50)
        }
        assertTrue(coordinator.isRunning)

        coordinator.cancelTask()
        job.join()

        assertFalse(coordinator.isRunning)
        val activeConv = coordinator.conversations.value.first { it.id == coordinator.activeConversationId.value }
        val assistantMsg = activeConv.messages.first { it.role == UiMessageRole.ASSISTANT }
        assertTrue(assistantMsg.text.contains("остановлена") || assistantMsg.text.contains("Задача"))
    }

    // 4. Подтверждение и отказ для опасных команд (Inline Approval)
    @Test
    fun testCommandApprovalAndRejection() = runBlocking {
        // Сценарий А: Отказ в выполнении опасной команды
        val toolCallReject = ToolCall(
            id = "c_rm_reject",
            name = "execute_command",
            arguments = """{"command": "rm", "args": ["-rf", "foo"]}""",
        )
        val mockAdapterReject = MockModelAdapter(
            ModelResponse(text = "Удаляю...", toolCalls = listOf(toolCallReject)),
            ModelResponse(text = "Завершено", toolCalls = emptyList()),
        )

        val coordinatorReject = createCoordinatorWithRealTools(
            workspacePath = tempDir,
            modelAdapter = mockAdapterReject,
        )

        val jobReject = coordinatorReject.startTask("Опасная команда")

        // Ожидаем появления запроса подтверждения
        for (i in 0 until 50) {
            if (coordinatorReject.approver.currentPending.value != null) break
            delay(100)
        }
        val pending = coordinatorReject.approver.currentPending.value
        assertNotNull(pending, "Approval request should be pending")
        assertEquals("rm", pending.command.command)

        // Отклоняем команду
        val rejectedFirst = coordinatorReject.rejectCommand(pending.id)
        assertTrue(rejectedFirst, "Initial rejectCommand should return true")

        // Повторное решение не должно приниматься
        val rejectedSecond = coordinatorReject.rejectCommand(pending.id)
        assertFalse(rejectedSecond, "Second rejectCommand should return false")
        val approvedAfterReject = coordinatorReject.approveCommand(pending.id)
        assertFalse(approvedAfterReject, "approveCommand after reject should return false")

        jobReject.join()

        val convReject = coordinatorReject.conversations.value.first { it.id == coordinatorReject.activeConversationId.value }
        val assistantMsgReject = convReject.messages.first { it.role == UiMessageRole.ASSISTANT }
        val toolExecReject = assistantMsgReject.toolExecutions.firstOrNull()
        assertNotNull(toolExecReject)
        assertEquals(ToolStatus.FAILED, toolExecReject.status)
        val rejectResult = toolExecReject.result
        assertNotNull(rejectResult)
        assertTrue(rejectResult.content.contains("rejected by user") || rejectResult.content.contains("Security violation"))

        // Проверяем карточку в сообщении
        assertEquals(1, assistantMsgReject.approvalRequests.size)
        val cardReject = assistantMsgReject.approvalRequests.first()
        assertEquals(pending.id, cardReject.id)
        assertEquals(ApprovalDecision.REJECTED, cardReject.decision)

        // Сценарий Б: Одобрение выполнения команды
        val safeJavaToolCall = ToolCall(
            id = "c_rm_approve",
            name = "execute_command",
            arguments = """{"command": "rm", "args": ["--help"]}""",
        )
        val mockAdapterApprove = MockModelAdapter(
            ModelResponse(text = "Выполняю rm...", toolCalls = listOf(safeJavaToolCall)),
            ModelResponse(text = "Выполнено", toolCalls = emptyList()),
        )
        val coordinatorApprove = createCoordinatorWithRealTools(
            workspacePath = tempDir,
            permissions = SecurityPermissions(
                allowExecuteCommand = true,
                requireApprovalForDangerous = true,
            ),
            modelAdapter = mockAdapterApprove,
        )

        val jobApprove = coordinatorApprove.startTask("Опасная команда одобрение")
        for (i in 0 until 50) {
            if (coordinatorApprove.approver.currentPending.value != null) break
            delay(100)
        }
        val pendingApprove = coordinatorApprove.approver.currentPending.value
        assertNotNull(pendingApprove)

        val approvedFirst = coordinatorApprove.approveCommand(pendingApprove.id)
        assertTrue(approvedFirst, "Initial approveCommand should return true")

        // Повторное решение не должно приниматься
        val approvedSecond = coordinatorApprove.approveCommand(pendingApprove.id)
        assertFalse(approvedSecond, "Second approveCommand should return false")
        val rejectedAfterApprove = coordinatorApprove.rejectCommand(pendingApprove.id)
        assertFalse(rejectedAfterApprove, "rejectCommand after approve should return false")

        jobApprove.join()

        val convApprove = coordinatorApprove.conversations.value.first { it.id == coordinatorApprove.activeConversationId.value }
        val assistantMsgApprove = convApprove.messages.first { it.role == UiMessageRole.ASSISTANT }
        val toolExecApprove = assistantMsgApprove.toolExecutions.firstOrNull()
        assertNotNull(toolExecApprove)
        val approveResult = toolExecApprove.result
        assertNotNull(approveResult)
        assertFalse(approveResult.content.contains("rejected by user"))

        // Проверяем сохранность карточки подтверждения со статусом APPROVED
        assertEquals(1, assistantMsgApprove.approvalRequests.size)
        val cardApprove = assistantMsgApprove.approvalRequests.first()
        assertEquals(pendingApprove.id, cardApprove.id)
        assertEquals(ApprovalDecision.APPROVED, cardApprove.decision)
    }

    // 5. Отмена задачи во время ожидания подтверждения (Inline Approval -> CANCELLED)
    @Test
    fun testInlineApprovalCancelledOnTaskCancel() = runBlocking {
        val toolCall = ToolCall(
            id = "c_rm_cancel",
            name = "execute_command",
            arguments = """{"command": "rm", "args": ["-rf", "bar"]}""",
        )
        val mockAdapter = MockModelAdapter(
            ModelResponse(text = "Запрос удаления...", toolCalls = listOf(toolCall)),
            ModelResponse(text = "Конец", toolCalls = emptyList()),
        )

        val coordinator = createCoordinatorWithRealTools(
            workspacePath = tempDir,
            modelAdapter = mockAdapter,
        )

        val job = coordinator.startTask("Удали bar")

        for (i in 0 until 50) {
            val conv = coordinator.conversations.value.first { it.id == coordinator.activeConversationId.value }
            val asst = conv.messages.firstOrNull { it.role == UiMessageRole.ASSISTANT }
            if (asst?.approvalRequests?.any { it.decision == ApprovalDecision.PENDING } == true) {
                break
            }
            delay(100)
        }

        // Проверяем, что карточка создана в PENDING статусе
        val activeConv = coordinator.conversations.value.first { it.id == coordinator.activeConversationId.value }
        val assistantMsg = activeConv.messages.first { it.role == UiMessageRole.ASSISTANT }
        assertEquals(1, assistantMsg.approvalRequests.size)
        val pendingCard = assistantMsg.approvalRequests.first()
        assertEquals(ApprovalDecision.PENDING, pendingCard.decision)

        // Отменяем задачу
        coordinator.cancelTask()
        job.join()

        // Проверяем, что карточка перешла в CANCELLED и осталась в истории
        val convAfterCancel = coordinator.conversations.value.first { it.id == coordinator.activeConversationId.value }
        val assistantMsgAfterCancel = convAfterCancel.messages.first { it.role == UiMessageRole.ASSISTANT }
        assertEquals(1, assistantMsgAfterCancel.approvalRequests.size)
        val cancelledCard = assistantMsgAfterCancel.approvalRequests.first()
        assertEquals(ApprovalDecision.CANCELLED, cancelledCard.decision)
        assertEquals(pendingCard.id, cancelledCard.id)
    }

    // 6. Изменение Workspace при активной задаче запрещено
    @Test
    fun testWorkspaceChangeRejectedWhileRunning() = runBlocking {
        val sleepSource = """
            public class SleepAppWs {
                public static void main(String[] args) throws Exception {
                    Thread.sleep(5000);
                }
            }
        """.trimIndent()
        Files.writeString(tempDir.resolve("SleepAppWs.java"), sleepSource)

        val toolCall = ToolCall(
            id = "c_sleep_ws",
            name = "execute_command",
            arguments = """{"command": "java", "args": ["SleepAppWs.java"]}""",
        )
        val mockAdapter = MockModelAdapter(
            ModelResponse(text = "Запускаю...", toolCalls = listOf(toolCall)),
            ModelResponse(text = "Готово", toolCalls = emptyList()),
        )

        val coordinator = createCoordinatorWithRealTools(
            workspacePath = tempDir,
            modelAdapter = mockAdapter,
        )

        val job = coordinator.startTask("Долгая задача")
        for (i in 0 until 50) {
            if (coordinator.isRunning) break
            delay(50)
        }
        assertTrue(coordinator.isRunning)

        // Попытка сменить workspace во время выполнения должна быть отклонена
        val changedWhileRunning = coordinator.changeWorkspace(otherDir)
        assertFalse(changedWhileRunning, "Workspace change must be rejected while task is running")
        assertEquals(tempDir, coordinator.workspacePath.value)

        // Отменяем задачу
        coordinator.cancelTask()
        job.join()
        assertFalse(coordinator.isRunning)

        // Теперь смена workspace должна успешно пройти
        val changedAfterStop = coordinator.changeWorkspace(otherDir)
        assertTrue(changedAfterStop, "Workspace change should succeed when idle")
        assertEquals(otherDir, coordinator.workspacePath.value)
    }
}
