# Архитектура Antigooglity

Данный документ фиксирует актуальное архитектурное состояние проекта Antigooglity после реализации и стабилизации скрытого браузерного runtime на базе Microsoft WebView2 и контроллера интерфейса Gemini (Этапы 1, 2, 3, 7.3, 7.3.1, 7.3.2).

---

## 1. Границы модулей

Проект состоит из двух основных Gradle-модулей и вспомогательного автономного инструмента:

1. **`:shared`** (Kotlin Multiplatform / JVM):
   - **`commonMain`**: ядро агента (**Agent Core**), абстракции моделей (`ModelAdapter`), событийная модель (`AgentEvent`), интерфейсы и базовые mock-реализации инструментов, кроссплатформенные ресурсы. Не содержит платформо-зависимого кода WebView2.
   - **`jvmMain`**:
     - JVM-реализация координатора (**`AgentCoordinator`**, **`AgentFactory`**), модели безопасности, парсеры аргументов команд.
     - **Браузерный клиент (`com.limer.antigooglity.webview2`)**:
       - `WebView2HostClient`: клиент дочернего процесса Host через JSON Lines IPC.
       - `WebView2Protocol`: строгий RFC-8259 JSON-парсер (`SimpleJsonValue`) и контракт сообщений протокола.
       - `GeminiDomController`: контроллер взаимодействия с Web UI Google Gemini (аудит состояния, ввод промпта, закрытие попапов, корреляция ходов диалога по устойчивым контейнерам).
   - **`commonTest` / `jvmTest`**: unit- и интеграционные тесты Agent Core, координатора, WebView2 IPC и контроллера Gemini.

2. **`:desktopApp`** (Compose Multiplatform Desktop Application):
   - Точка входа в приложение (`MainKt`).
   - Десктопный пользовательский интерфейс (UI) на базе Jetpack Compose for Desktop.
   - Зависит исключительно от `:shared`.

3. **`tools/webview2-host`** (.NET 8 WinForms Host):
   - Отдельный дочерний C#-процесс (`AntigooglityWebView2Host.exe`).
   - Создаёт скрытый контрол Microsoft WebView2 (`IsVisible = false`) с постоянным пользовательским профилем.
   - Поддерживает временный видимый диагностический режим (`SET_VISIBILITY`).
   - Обеспечивает корректный STA Windows Message Loop и строго последовательное асинхронное исполнение команд через `System.Threading.Channels.Channel`.

---

## 2. Архитектура Agent Core (`shared/commonMain`, `shared/jvmMain`)

Agent Core представляет собой независимое, реактивное ядро выполнения автономных агентных циклов.

### Ключевые компоненты:
- **`Agent`**: фасад выполнения задачи. Принимает пользовательский запрос и координирует итерации `AgentLoop`.
- **`AgentLoop`**: цикл рассуждений и действий (Reasoning and Action Loop). На каждой итерации:
  1. Запрашивает следующее действие у `ModelAdapter`.
  2. Генерирует событие `AgentEvent.Thinking`.
  3. Если модель запрашивает вызовы инструментов (`ToolCall`), последовательно выполняет их через `ToolExecutor`.
  4. Генерирует события `AgentEvent.ToolRequested` и `AgentEvent.ToolCompleted`.
  5. Передаёт результаты работы инструментов обратно в контекст диалога.
  6. При получении финального ответа модели завершает цикл событием `AgentEvent.Completed`.
- **`AgentContext`**: хранит историю сообщений диалога (`AgentMessage`: `SYSTEM`, `USER`, `ASSISTANT`, `TOOL`), имя задачи и контекстные метаданные.
- **`AgentConfig`**: конфигурация агента (системный промпт, ограничение максимального числа итераций `maxIterations`).
- **`AgentEvent`**: типизированные события жизненного цикла (`Started`, `Thinking`, `ToolRequested`, `ToolCompleted`, `Completed`, `Failed`).
- **`ToolCall` & `ToolResult`**: контракты вызова инструмента (ID, имя, JSON-аргументы) и результата его выполнения (ID, текстовый контент, флаг успешности).
- **`ToolExecutor`**: интерфейс выполнения вызовов инструментов агентом.
- **`ModelAdapter` & `ModelResponse`**: контракт интеграции языковой модели и структура её ответа (текст + список вызовов `ToolCall`).
- **`AgentCoordinator`**: координатор прикладного уровня, связывающий Compose UI с ядром агента. Управляет переключением диалогов, состоянием выполнения (`ExecutionStatus`), потоками событий (`StateFlow`), директорией workspace, разрешениями безопасности (`SecurityPermissions`) и одобрением команд (`UiCommandApprover`).

---

## 3. WebView2 Browser Runtime: архитектура и границы

### 3.1 Граница Kotlin / .NET

```
+-----------------------------------------------------------+
| Kotlin/JVM (:shared/jvmMain)                              |
|                                                           |
|  [GeminiDomController] ---> [WebView2HostClient]          |
|                                     | (stdin/stdout)      |
+-------------------------------------|---------------------+
                                      | JSON Lines IPC
+-------------------------------------|---------------------+
| .NET 8 Host (AntigooglityWebView2Host.exe)                |
|                                     v                     |
|  [RunStdinReader] ---> [Channel<HostCommand>]             |
|                                     | (Sequential STA)    |
|                             [BrowserController]           |
|                                     |                     |
|                           [Microsoft WebView2]            |
|                     (Hidden WinForms HWND / STA Loop)     |
+-----------------------------------------------------------+
```

### 3.2 JSON Lines IPC Протокол

Обмен между Kotlin и .NET Host осуществляется строками UTF-8 JSON Lines через перенаправленные потоки stdin / stdout:

- **Команда из Kotlin (stdin Host):**
  ```json
  {
    "requestId": "req-1a2b3c4d",
    "command": "EXECUTE_SCRIPT",
    "script": "(function() { ... })()",
    "timeoutMs": 15000
  }
  ```
- **Ответ от Host (stdout Kotlin):**
  ```json
  {
    "requestId": "req-1a2b3c4d",
    "command": "EXECUTE_SCRIPT",
    "success": true,
    "data": { "result": { ... } },
    "error": null
  }
  ```

Команды протокола:
- `PING`: проверка связи и готовности WebView2.
- `GET_STATUS`: состояние инициализации, путь к профилю, видимость.
- `GET_CURRENT_URL`: текущий адрес страницы.
- `GET_NAVIGATION_STATUS`: детальный статус навигации и заголовок документа.
- `SET_VISIBILITY`: переключение видимости окна (скрытый режим по умолчанию, видимый для интерактивной диагностики).
- `NAVIGATE`: переход по URL с ожиданием завершения навигации.
- `EXECUTE_SCRIPT`: выполнение JavaScript в контексте страницы с возвратом распарсенного JSON.
- `GET_DOCUMENT_INFO`: чтение свойств `location.href`, `title`, `readyState`, `visibilityState`.
- `GET_PAGE_TEXT`: извлечение текстового содержимого страницы с ограничением длины.
- `CLOSE`: корректное завершение процесса Host.

### 3.3 Последовательное выполнение команд на STA-потоке

В .NET Host реализована очередь на базе `System.Threading.Channels.Channel<HostCommand>`. Фоновый поток `RunStdinReader` считывает команды из stdin и помещает их в канал, а цикл `ProcessCommandsSequentiallyAsync` на STA-потоке последовательно ожидает и выполняет каждую команду. Это исключает гонки между параллельными командами, изменяющими состояние браузера, и предотвращает синхронную блокировку WinForms STA message loop.

### 3.4 Профили пользователей и изоляция

- **Рабочий авторизованный профиль (Production / Manual Diagnostic):**
  - Расположение: `%LOCALAPPDATA%\Antigooglity\webview2-profile`.
  - Содержит сохранённые cookies, сессии авторизации Google Account и локальные данные.
  - Используется по умолчанию при работе приложения и в ручном `geminiRealSmokeTest`.
- **Изолированный тестовый профиль (Integration Tests):**
  - Поддерживается параметр CLI `--user-data-dir <path>` или переменная окружения `ANTIGOOGLITY_WEBVIEW2_PROFILE`.
  - Все обычные тесты `WebView2HostIntegrationTest` создают временную директорию через `Files.createTempDirectory(...)` и удаляют её после выполнения, гарантируя сохранность пользовательского профиля.

---

## 4. Контроллер Gemini DOM (`GeminiDomController`)

`GeminiDomController` изолирует взаимодействие с веб-интерфейсом Google Gemini (`https://gemini.google.com/app`):

### 4.1 Аудит состояния (`getPageState`)
Разделяет следующие состояния:
- `isScriptAvailable`: доступность выполнения JS;
- `isDocumentLoaded`: полная загрузка DOM (`complete` / `interactive`);
- `isGeminiUrl`: адрес страницы строго `https://gemini.google.com`;
- `isChatReady`: готовность контейнера чата;
- `hasEditor` & `isEditorAccessible`: присутствие и доступность `.ql-editor`;
- `isEditorEmpty`: отсутствие постороннего текста в поле ввода;
- `hasSendButton` & `isSendButtonDisabled`: статус кнопки отправки;
- `isGenerating`: статус активной генерации ответа моделью.

### 4.2 Надежная отправка промпта (`sendPrompt`)
1. **Проверка входных данных**: пустой prompt или prompt из пробелов сразу отклоняется (`EMPTY_PROMPT`).
2. **Предусловия**: хост строго `https://gemini.google.com`, редактор найден и доступен, генерация не выполняется, поле ввода пустое (при наличии текста — `EDITOR_NOT_EMPTY`).
3. **Фиксация снимка диалога**: снимок контейнеров сообщений (`GeminiConversationSnapshot`) валидируется до модификации DOM.
4. **Вставка и верификация текста**: текст вставляется через `document.execCommand('insertText', false, text)` и проверяется совпадение текста в редакторе с отправляемым промптом (`INSERTED_TEXT_MISMATCH`).
5. **Однократный триггер отправки**: если кнопка отправки найдена, но отключена — Enter не отправляется автоматически, возвращается ошибка `SEND_BUTTON_DISABLED`.
6. **Подтверждение отправки в DOM**: подтверждение требует фактического появления нового пользовательского сообщения в DOM с текстом отправленного промпта (только очистки редактора недостаточно). Если подтверждение не получено за 5 секунд, возвращается `SEND_NOT_CONFIRMED` без повторной отправки.

### 4.3 Корреляция ходов диалога (`waitForResponse`)
1. **Идентификация контейнеров**: контейнеры сообщений (`model-response`, `[data-test-id="model-response"]`) фильтруются от вложенных элементов (`message-content`, `.markdown`), гарантируя совпадение подсчёта в snapshot и в списке ответов.
2. **Идентификация по ID и позиции**: фиксируются ID существующих ответов (`modelMessageIds`) и их количество (`modelResponseCount`). Новый ответ идентифицируется по появлению контейнера с новым ID или по индексу, строго превышающему предыдущий счётчик.
3. **Идентичные ответы**: два последовательных ответа с одинаковым текстом корректно различаются как разные ходы благодаря независимым идентификаторам контейнеров и целевому индексу хода.
4. **Стабилизация текста**: дожидается завершения генерации (`!isGenerating`) и совпадения текста нового ответа на протяжении 2 последовательных интервалов опроса.
5. **Таймаут**: при истечении времени ожидания метод возвращает `found = false` (незавершённый ответ никогда не возвращается с `found = true`), а частичный текст возвращается в поле `partialText`.

---

## 5. Организация тестирования

### 5.1 Обычный прогон тестов (`:shared:allTests`)
- Не отправляет сетевые запросы в реальный аккаунт Google Gemini.
- Запускает:
  - 15 unit-тестов `GeminiDomControllerTest` через интерфейс `ScriptExecutor` (проверка сценариев смены ходов, одинаковых ответов, вложенных элементов, частичных ответов, отмены корутин, ошибок редактора, парсинга RFC-8259 JSON со строгой валидацией).
  - 8 интеграционных тестов `WebView2HostIntegrationTest` на изолированном временном профиле.
  - Все unit-тесты ядра агента и инструментов.
- Тест `GeminiRealSmokeTest` корректно пропускается через `Assume.assumeTrue` (1 skipped).

### 5.2 Ручной реальный Smoke Test (`geminiRealSmokeTest`)
Для ручной проверки взаимодействия с авторизованной сессией Gemini:

```powershell
.\gradlew.bat :shared:geminiRealSmokeTest
```
или:
```powershell
.\gradlew.bat :shared:jvmTest --tests "com.limer.antigooglity.webview2.gemini.GeminiRealSmokeTest" -Dantigooglity.gemini.real.smoke=true
```

Поведение:
1. Запускает скрытый WebView2 Host с реальным профилем `%LOCALAPPDATA%\Antigooglity\webview2-profile`.
2. **Ход 1**: Генерирует уникальный маркер `ANTIGOOGLITY_SMOKE_ALPHA_<UUID>` и ожидает его возвращение от Gemini.
3. **Ход 2**: В том же диалоге генерирует второй маркер `ANTIGOOGLITY_SMOKE_BETA_<UUID>` и отправляет второй запрос.
4. Проверяет корреляцию: ответ 2 не равен ответу 1, завершил генерацию и содержит маркер Beta.
5. Сохраняет результат в `build/diagnostics/gemini-last-response.txt`.

> [!NOTE]
> Ручной smoke test взаимодействует с настоящим аккаунтом пользователя и добавляет 2 сообщения в историю чата Gemini.

---

## 6. Статус и разделение с будущими этапами

- **Реализовано и верифицировано:**
  - .NET 8 WinForms WebView2 Host со скрытым режимом, очередью команд и безопасным завершением.
  - Постоянный профиль авторизации Google.
  - JSON Lines IPC протокол со строгим RFC-8259 JSON-парсером (`SimpleJsonValue`).
  - `GeminiDomController` с проверками состояний, защитой от вложенных DOM-элементов, корреляцией ходов диалога по устойчивым контейнерам и защитой от ложного подтверждения отправки.
  - 100% прохождение всех автоматических тестов без внешних зависимостей (80 тестов: 79 passed, 1 skipped opt-in).
- **Будущий этап (Планируется):**
  - Реализация `GeminiWebView2ModelAdapter`, реализующего интерфейс `ModelAdapter`.
  - Подключение адаптера к `AgentCoordinator` / `AgentLoop` для полноценного диалога агента с Gemini.
  - Потоковая передача чанков ответа в события `AgentEvent.ModelStreamEvent`.
  *(Компонент ModelAdapter для WebView2 ещё не реализован и не входит в состав текущей сборки)*.
