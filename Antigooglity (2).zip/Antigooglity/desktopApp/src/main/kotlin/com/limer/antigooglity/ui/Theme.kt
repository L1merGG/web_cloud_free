package com.limer.antigooglity.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val BgDark = Color(0xFF131417)
val PanelDark = Color(0xFF1A1C20)
val CardDark = Color(0xFF22252B)
val BgCard = CardDark
val BorderDark = Color(0xFF2E323A)
val BorderDarkLight = Color(0xFF3F444E)
val PrimaryBlue = Color(0xFF3B82F6)
val PrimaryBlueHover = Color(0xFF2563EB)
val AccentBlue = PrimaryBlue
val AccentTeal = Color(0xFF14B8A6)
val AccentPurple = Color(0xFFA855F7)
val MutedGray = Color(0xFF6B7280)
val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)
val SuccessGreen = Color(0xFF10B981)
val DangerRed = Color(0xFFEF4444)
val WarningAmber = Color(0xFFF59E0B)

val AntigooglityColorScheme = darkColorScheme(
    background = BgDark,
    surface = PanelDark,
    surfaceVariant = CardDark,
    primary = PrimaryBlue,
    onPrimary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary,
    outline = BorderDark,
    error = DangerRed,
)

val AntigooglityShapes = Shapes(
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(14.dp),
)

@Composable
fun AntigooglityTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AntigooglityColorScheme,
        shapes = AntigooglityShapes,
        content = content,
    )
}
