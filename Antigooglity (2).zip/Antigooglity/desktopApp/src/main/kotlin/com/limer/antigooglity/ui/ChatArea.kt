package com.limer.antigooglity.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.limer.antigooglity.coordinator.Conversation
import com.limer.antigooglity.coordinator.UiMessage
import com.limer.antigooglity.coordinator.UiMessageRole
import java.nio.file.Path

@Composable
fun ChatArea(
    conversation: Conversation?,
    workspacePath: Path,
    isRunning: Boolean,
    statusText: String,
    onSendMessage: (String) -> Unit,
    onCancelTask: () -> Unit,
    onApproveCommand: (String) -> Unit,
    onRejectCommand: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()

    // Auto-scroll to bottom on new messages, events, or approvals
    LaunchedEffect(
        conversation?.messages?.size,
        conversation?.messages?.lastOrNull()?.toolExecutions?.size,
        conversation?.messages?.lastOrNull()?.approvalRequests?.size,
    ) {
        val total = conversation?.messages?.size ?: 0
        if (total > 0) {
            listState.animateScrollToItem(total - 1)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BgDark),
    ) {
        if (conversation == null || conversation.messages.isEmpty()) {
            EmptyChatCenterView(
                workspacePath = workspacePath,
                statusText = statusText,
                isRunning = isRunning,
                onSendMessage = onSendMessage,
                onCancelTask = onCancelTask,
            )
        } else {
            SelectionContainer {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter,
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 860.dp)
                            .padding(horizontal = 24.dp, vertical = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(20.dp),
                    ) {
                        items(conversation.messages, key = { it.id }) { msg ->
                            MessageItem(
                                msg = msg,
                                onApproveCommand = onApproveCommand,
                                onRejectCommand = onRejectCommand,
                            )
                        }

                        if (isRunning) {
                            item {
                                RunningThinkingIndicator()
                            }
                        }

                        // Bottom spacer so content doesn't get covered by input bar
                        item {
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyChatCenterView(
    workspacePath: Path,
    statusText: String,
    isRunning: Boolean,
    onSendMessage: (String) -> Unit,
    onCancelTask: () -> Unit,
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        // Soft blue radial ambient glow
        Box(
            modifier = Modifier
                .size(540.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            PrimaryBlue.copy(alpha = 0.05f),
                            Color.Transparent,
                        )
                    )
                )
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .widthIn(max = 800.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
        ) {
            Text(
                text = "С чего начнём?",
                fontSize = 34.sp,
                fontWeight = FontWeight.Normal,
                letterSpacing = (-0.5).sp,
                color = TextPrimary,
            )

            Text(
                text = "Папка: ${workspacePath.fileName ?: workspacePath}",
                fontSize = 12.sp,
                color = TextMuted.copy(alpha = 0.7f),
                modifier = Modifier.padding(top = 6.dp, bottom = 26.dp),
            )

            // Central AI Composer on empty screen
            BottomInputBar(
                statusText = statusText,
                isRunning = isRunning,
                onSendMessage = onSendMessage,
                onCancelTask = onCancelTask,
            )
        }
    }
}

@Composable
private fun MessageItem(
    msg: UiMessage,
    onApproveCommand: (String) -> Unit,
    onRejectCommand: (String) -> Unit,
) {
    when (msg.role) {
        UiMessageRole.USER -> {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = CardDark,
                    modifier = Modifier.widthIn(max = 680.dp),
                ) {
                    Text(
                        text = msg.text,
                        fontSize = 14.sp,
                        color = TextPrimary,
                        lineHeight = 22.sp,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                    )
                }
            }
        }
        UiMessageRole.ASSISTANT -> {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Assistant header with subtle icon
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 8.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .background(PrimaryBlue, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("✦", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Antigooglity",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                        )
                    }

                    // 1. Tool Executions (compact cards)
                    if (msg.toolExecutions.isNotEmpty()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
                        ) {
                            msg.toolExecutions.forEach { toolExec ->
                                ToolCard(tool = toolExec)
                            }
                        }
                    }

                    // 2. Inline Command Approvals
                    if (msg.approvalRequests.isNotEmpty()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
                        ) {
                            msg.approvalRequests.forEach { approvalReq ->
                                InlineApprovalCard(
                                    request = approvalReq,
                                    onApprove = onApproveCommand,
                                    onReject = onRejectCommand,
                                )
                            }
                        }
                    }

                    // 3. Assistant text response
                    if (msg.text.isNotBlank()) {
                        Text(
                            text = msg.text,
                            fontSize = 14.sp,
                            color = TextPrimary,
                            lineHeight = 22.sp,
                            modifier = Modifier.padding(start = 4.dp, top = 2.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RunningThinkingIndicator() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 4.dp, top = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(14.dp),
            strokeWidth = 2.dp,
            color = PrimaryBlue,
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "Агент выполняет задачу...",
            fontSize = 13.sp,
            color = TextSecondary,
        )
    }
}
