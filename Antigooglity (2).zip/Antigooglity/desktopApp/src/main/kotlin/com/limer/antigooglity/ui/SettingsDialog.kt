package com.limer.antigooglity.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.limer.antigooglity.coordinator.SecurityPermissions

@Composable
fun SettingsDialog(
    currentPermissions: SecurityPermissions,
    onSave: (SecurityPermissions) -> Unit,
    onDismiss: () -> Unit,
) {
    var allowRead by remember { mutableStateOf(currentPermissions.allowReadFile) }
    var allowWrite by remember { mutableStateOf(currentPermissions.allowWriteFile) }
    var allowDelete by remember { mutableStateOf(currentPermissions.allowDeleteFile) }
    var allowExecute by remember { mutableStateOf(currentPermissions.allowExecuteCommand) }
    var allowArbitrary by remember { mutableStateOf(currentPermissions.allowArbitraryCommands) }
    var requireApproval by remember { mutableStateOf(currentPermissions.requireApprovalForDangerous) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = PanelDark,
            modifier = Modifier
                .width(520.dp)
                .border(1.dp, BorderDarkLight, RoundedCornerShape(12.dp)),
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = "Настройки безопасности и разрешений",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                )
                Text(
                    text = "Управляйте границами доступа агента к файлам и командной строке.",
                    fontSize = 13.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
                )

                // 1. Read files
                PermissionCheckboxItem(
                    title = "Разрешить чтение файлов",
                    subtitle = "Агент может просматривать файлы и каталоги в пределах рабочей директории.",
                    checked = allowRead,
                    onCheckedChange = { allowRead = it },
                )

                // 2. Write files
                PermissionCheckboxItem(
                    title = "Разрешить запись файлов",
                    subtitle = "Агент может создавать и изменять файлы в рабочей директории.",
                    checked = allowWrite,
                    onCheckedChange = { allowWrite = it },
                )

                // 3. Delete files (dangerous)
                PermissionCheckboxItem(
                    title = "Разрешить удаление файлов",
                    subtitle = "Позволяет удалять файлы в рабочей области.",
                    warning = "⚠️ Внимание: удаление файлов отключено по умолчанию для защиты данных!",
                    checked = allowDelete,
                    onCheckedChange = { allowDelete = it },
                )

                // 4. Execute commands
                PermissionCheckboxItem(
                    title = "Разрешить выполнение команд",
                    subtitle = "Запуск компиляторов и утилит (git, python, java, gradle) из списка разрешённых.",
                    checked = allowExecute,
                    onCheckedChange = { allowExecute = it },
                )

                // 5. Arbitrary commands (dangerous)
                PermissionCheckboxItem(
                    title = "Разрешить произвольные команды",
                    subtitle = "Снятие ограничений allowlist для запуска любых утилит на компьютере.",
                    warning = "⚠️ Опасная настройка! Агент сможет запускать любые бинарные файлы вне allowlist.",
                    checked = allowArbitrary,
                    onCheckedChange = { allowArbitrary = it },
                )

                // 6. Require approval for dangerous
                PermissionCheckboxItem(
                    title = "Требовать подтверждение опасных команд",
                    subtitle = "Перед запуском команд вроде rm, del, apt запрашивать явное подтверждение пользователя.",
                    checked = requireApproval,
                    onCheckedChange = { requireApproval = it },
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                        border = BorderStroke(1.dp, BorderDarkLight),
                    ) {
                        Text("Отмена")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = {
                            onSave(
                                SecurityPermissions(
                                    allowReadFile = allowRead,
                                    allowWriteFile = allowWrite,
                                    allowDeleteFile = allowDelete,
                                    allowExecuteCommand = allowExecute,
                                    allowArbitraryCommands = allowArbitrary,
                                    requireApprovalForDangerous = requireApproval,
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                    ) {
                        Text("Сохранить")
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionCheckboxItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    warning: String? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = CheckboxDefaults.colors(
                checkedColor = PrimaryBlue,
                uncheckedColor = BorderDarkLight,
                checkmarkColor = Color.White,
            ),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimary,
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = TextSecondary,
            )
            if (warning != null && checked) {
                Box(
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .background(WarningAmber.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                ) {
                    Text(
                        text = warning,
                        fontSize = 11.sp,
                        color = WarningAmber,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}
