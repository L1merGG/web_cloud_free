package com.limer.antigooglity.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.limer.antigooglity.coordinator.AgentCoordinator
import com.limer.antigooglity.coordinator.ExecutionStatus

@Composable
fun MainScreen(
    coordinator: AgentCoordinator,
) {
    val workspacePath by coordinator.workspacePath.collectAsState()
    val permissions by coordinator.permissions.collectAsState()
    val conversations by coordinator.conversations.collectAsState()
    val activeConversationId by coordinator.activeConversationId.collectAsState()
    val executionStatus by coordinator.executionStatus.collectAsState()
    val statusText by coordinator.statusText.collectAsState()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var isSidebarCollapsed by remember { mutableStateOf(false) }

    val activeConversation = conversations.firstOrNull { it.id == activeConversationId }
    val isRunning = executionStatus == ExecutionStatus.RUNNING
    val hasMessages = activeConversation?.messages?.isNotEmpty() == true

    AntigooglityTheme {
        Box(modifier = Modifier.fillMaxSize().background(BgDark)) {
            Row(modifier = Modifier.fillMaxSize()) {
                // Left Sidebar (with collapse support)
                Sidebar(
                    workspacePath = workspacePath,
                    conversations = conversations,
                    activeConversationId = activeConversationId,
                    isRunning = isRunning,
                    isCollapsed = isSidebarCollapsed,
                    onToggleCollapse = { isSidebarCollapsed = !isSidebarCollapsed },
                    onNewConversation = { coordinator.newConversation() },
                    onSelectConversation = { coordinator.selectConversation(it) },
                    onDeleteConversation = { coordinator.deleteConversation(it) },
                    onChangeWorkspace = {
                        val picked = DirectoryPicker.pickDirectory(initialPath = workspacePath)
                        if (picked != null) {
                            coordinator.changeWorkspace(picked)
                        }
                    },
                    onOpenSettings = { showSettingsDialog = true },
                )

                // Central Workspace Area
                Column(modifier = Modifier.weight(1f).fillMaxSize()) {
                    ChatArea(
                        conversation = activeConversation,
                        workspacePath = workspacePath,
                        isRunning = isRunning,
                        statusText = statusText,
                        onSendMessage = { prompt -> coordinator.startTask(prompt) },
                        onCancelTask = { coordinator.cancelTask() },
                        onApproveCommand = { id -> coordinator.approveCommand(id) },
                        onRejectCommand = { id -> coordinator.rejectCommand(id) },
                        modifier = Modifier.weight(1f),
                    )

                    // In active chat, BottomInputBar is pinned at the bottom
                    if (hasMessages) {
                        BottomInputBar(
                            statusText = statusText,
                            isRunning = isRunning,
                            onSendMessage = { prompt -> coordinator.startTask(prompt) },
                            onCancelTask = { coordinator.cancelTask() },
                        )
                    }
                }
            }

            // Security Permissions Settings Dialog
            if (showSettingsDialog) {
                SettingsDialog(
                    currentPermissions = permissions,
                    onSave = { updated ->
                        coordinator.updatePermissions(updated)
                        showSettingsDialog = false
                    },
                    onDismiss = { showSettingsDialog = false },
                )
            }
        }
    }
}
